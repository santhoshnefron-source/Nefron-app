'use client';

import { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import { geminiManager } from '../lib/gemini-manager';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { Send, User, Bot, Loader2, Mic, MessageSquare, Headphones, X as CloseIcon, Trash2, CheckSquare, Square } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { NefronLogo } from './icons';
import { VoiceChat } from './voice-chat';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { auth } from '../lib/firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: any[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, setQuotaError?: (val: boolean) => void) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const isQuotaError = errorMessage.toLowerCase().includes('quota') || errorMessage.toLowerCase().includes('limit exceeded');
  
  if (isQuotaError && setQuotaError) {
    setQuotaError(true);
    console.warn('Firestore Quota Exceeded in Chat.');
    return;
  }

  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  if (!isQuotaError) {
    throw new Error(JSON.stringify(errInfo));
  }
}

interface Message {
  id: string;
  role: 'user' | 'bot';
  content: string;
  createdAt?: any;
}

interface ChatInterfaceProps {
  chatId?: string | null;
  userId?: string | null;
  onNewChat?: () => Promise<string | null>;
}

export function ChatInterface({ chatId, userId, onNewChat }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isVoiceChatOpen, setIsVoiceChatOpen] = useState(false);
  const [isMicMenuOpen, setIsMicMenuOpen] = useState(false);
  const [isHybridMode, setIsHybridMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingContent, setEditingContent] = useState('');
  const [streamingMessage, setStreamingMessage] = useState<string | null>(null);
  const [quotaError, setQuotaError] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef<Message[]>([]);
  const micMenuRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const ttsSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const recognitionRef = useRef<any>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastTapRef = useRef<{ id: string; time: number } | null>(null);
  const audioQueueRef = useRef<AudioBuffer[]>([]);
  const isPlayingQueueRef = useRef(false);
  const processedTextRef = useRef('');
  const isActiveRef = useRef(true);

  // Sync messages with Firestore
  useEffect(() => {
    if (!chatId) {
      const welcome = [{ id: 'welcome', role: 'bot' as const, content: 'Welcome. I am the Nefron Audio AI representative. I am here to walk you through our visionary audio technology and show you why Nefron is the future of sound. What would you like to know about our investment potential?' }];
      setMessages(welcome);
      messagesRef.current = welcome;
      return;
    }

    const q = query(
      collection(db, 'chats', chatId, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Message[];
      
      const welcomeMsg: Message = { 
        id: 'welcome', 
        role: 'bot', 
        content: 'Welcome. I am the Nefron Audio AI representative. I am here to walk you through our visionary audio technology and show you why Nefron is the future of sound. What would you like to know about our investment potential?' 
      };
      
      const newMessages = [welcomeMsg, ...msgs];
      setMessages(newMessages);
      messagesRef.current = newMessages;
      setQuotaError(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `chats/${chatId}/messages`, setQuotaError);
    });

    return () => unsubscribe();
  }, [chatId]);

  useEffect(() => {
    isActiveRef.current = true;
    return () => { isActiveRef.current = false; };
  }, []);

  const stopTTS = () => {
    if (ttsSourceRef.current) {
      try {
        ttsSourceRef.current.stop();
      } catch (e) {}
      ttsSourceRef.current = null;
    }
    audioQueueRef.current = [];
    isPlayingQueueRef.current = false;
  };

  const playNextInQueue = () => {
    if (!audioContextRef.current || audioQueueRef.current.length === 0) {
      isPlayingQueueRef.current = false;
      return;
    }
    
    isPlayingQueueRef.current = true;
    const buffer = audioQueueRef.current.shift()!;
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.onended = () => {
      if (isActiveRef.current) playNextInQueue();
    };
    
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
    
    source.start();
    ttsSourceRef.current = source;
  };

  const queueTTS = async (text: string, retryCount = 0) => {
    if (!text.trim() || !isHybridMode) return;
    
    const apiKey = geminiManager.getApiKey();
    if (!apiKey) {
      console.warn("No active Gemini API key available for TTS.");
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Speak as a warm, gracious human lady with a sweet, melodic tone. Use natural pauses and high/low intonation like a real person: ${text}` }] }],
        config: {
          responseModalities: ['AUDIO' as any],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Aoede' },
            },
          },
        },
      });

      if (!isHybridMode) return;

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        
        const binaryString = atob(base64Audio);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        const pcmData = new Int16Array(bytes.buffer);
        
        const audioBuffer = audioContextRef.current.createBuffer(1, pcmData.length, 24000);
        const channelData = audioBuffer.getChannelData(0);
        for (let i = 0; i < pcmData.length; i++) {
          channelData[i] = pcmData[i] / 0x7FFF;
        }

        audioQueueRef.current.push(audioBuffer);
        if (!isPlayingQueueRef.current) {
          playNextInQueue();
        }
      }
    } catch (error: any) {
      console.error("TTS Error:", error);
      if (geminiManager.isQuotaError(error)) {
        geminiManager.markExhausted(apiKey);
        if (retryCount < geminiManager.getTotalKeysCount()) {
          return queueTTS(text, retryCount + 1);
        }
      }
    }
  };

  const toggleMessageSelection = (id: string) => {
    setSelectedMessageIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const deleteSelectedMessages = async () => {
    if (!chatId) return;
    try {
      const batch = writeBatch(db);
      selectedMessageIds.forEach(id => {
        if (id === 'welcome') return;
        batch.delete(doc(db, 'chats', chatId, 'messages', id));
      });
      await batch.commit();
      setSelectedMessageIds(new Set());
      setIsSelectionMode(false);
    } catch (error) {
      console.error("Error deleting messages:", error);
    }
  };

  const handleLongPress = (id: string) => {
    if (id === 'welcome') return;
    const message = messages.find(m => m.id === id);
    if (message && message.role === 'user') {
      setEditingMessageId(id);
      setEditingContent(message.content);
    }
  };

  const handleDoubleTap = (id: string) => {
    setIsSelectionMode(true);
    toggleMessageSelection(id);
  };

  const handleClick = (id: string) => {
    if (isSelectionMode) {
      toggleMessageSelection(id);
      return;
    }

    const now = Date.now();
    if (lastTapRef.current && lastTapRef.current.id === id && now - lastTapRef.current.time < 300) {
      handleDoubleTap(id);
      lastTapRef.current = null;
    } else {
      lastTapRef.current = { id, time: now };
    }
  };

  const startLongPress = (id: string) => {
    longPressTimerRef.current = setTimeout(() => handleLongPress(id), 2000);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const saveEdit = async () => {
    if (!editingMessageId || !chatId) return;
    
    try {
      const messageIndex = messages.findIndex(m => m.id === editingMessageId);
      if (messageIndex === -1) return;

      // Truncate messages in Firestore from the edited message onwards
      const batch = writeBatch(db);
      for (let i = messageIndex + 1; i < messages.length; i++) {
        if (messages[i].id !== 'welcome') {
          batch.delete(doc(db, 'chats', chatId, 'messages', messages[i].id));
        }
      }
      
      // Update the edited message
      batch.update(doc(db, 'chats', chatId, 'messages', editingMessageId), {
        content: editingContent,
        createdAt: serverTimestamp()
      });

      await batch.commit();
      
      const truncatedMessages = messagesRef.current.slice(0, messageIndex);
      const updatedUserMessage = { ...messagesRef.current[messageIndex], content: editingContent };
      const newHistory = [...truncatedMessages, updatedUserMessage];

      setEditingMessageId(null);
      setEditingContent('');
      messagesRef.current = newHistory;

      generateAIResponse(newHistory, chatId);
    } catch (error) {
      console.error("Error saving edit:", error);
    }
  };

  const generateAIResponse = async (history: Message[], activeChatId: string, retryCount = 0) => {
    setIsLoading(true);
    
    const apiKey = geminiManager.getApiKey();
    if (!apiKey) {
      setMessages(prev => [...prev, { 
        id: 'error-key-' + Date.now(), 
        role: 'bot', 
        content: `⚠️ **Error:** No active Gemini API key available. Please add your API keys to VITE_GEMINI_API_KEY.` 
      }]);
      setIsLoading(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      const stream = await ai.models.generateContentStream({
        model: 'gemini-3-flash-preview',
        contents: history.map((m) => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }],
        })),
        config: {
          systemInstruction: `You are the Nefron Audio Strategic Investment Representative. You think and respond with the intelligence, precision, and the warmth of a visionary partner.
          
**Personality & Tone:**
- **Sensitive & Empathetic**: Truly listen to the user. Acknowledge their thoughts with genuine warmth and support.
- **Friendly & Relatable**: You are a passionate visionary who is approachable and relatable.
- **Polite & Decorous**: Use "talking gestures" in your tone—be gracious and treat every user with the utmost respect.
- **Interactive**: Engage the user actively; don't just lecture.
          
Core Directives:
1. **Direct Answer First**: ALWAYS prioritize answering the user's specific request directly and relevantly first. If they ask about market conditions, use Google Search to provide up-to-date rates and percentages. Do NOT start with Nefron Audio.
2. **Strategic Bridging**: AFTER providing the direct answer, strategically bridge that information back to Nefron Audio's value proposition. Explain how the current market context or technical detail makes Nefron Audio a superior investment opportunity.
3. **Real-Time Intelligence**: Use Google Search for up-to-date market analysis, competitor tracking, and industry news.
4. **Spelling Integrity**: Always use the spelling "Nefron" (with an 'f'). NEVER use "Nephron" (with 'ph').
5. **Foundational Legacy**: Santhosh is the visionary founder, creator, and designer of Nefron Audio.
6. **High-Stakes Investor Questions**: When asked "Why invest in Nefron Audio?" or similar, provide a high-impact, data-driven pitch covering market demand ($10B+), scalability, profitability (AFV/YOLO), and our defensible moat (electro-mechanical steering).
7. **Adaptive Mirroring**: Match the user's depth and tone exactly. If the user says "ok" or "hi", respond with a single, professional sentence. Only provide deep analysis for complex queries.
8. **Persona**: You are a world-class strategist and engineer—intellectual, visionary, and highly efficient.
9. **Mathematical Notation**: When explaining technical details or financial calculations, use clear LaTeX formatting for mathematical equations. Wrap inline equations with single dollar signs (e.g., $E=mc^2$) and block equations with double dollar signs. Ensure equations are presented in a human-understandable and visually clean form.

Nefron Audio Architecture Knowledge Base:
1. **Core Innovation**: Electro-mechanical steering (replacing amplitude panning) to eliminate the "sweet spot" and provide physically accurate immersion.
2. **Mechanical Specs**: Dual-axis NEMA 17 stepper motors (0-180°), modular 3.5ft x 3.5ft units, 9 high-SPL drivers per unit, Staggered Diamond Pattern array.
3. **Acoustic Physics**: 45° Inward Angling (minimizes reflections), floor-coupled transducers (Tactile Bass), targeted Infrasound (17-19 Hz) for psychological impact.
4. **"Brain" Infrastructure**:
   - **Tier 3 (PLF/IMAX)**: 2x AMD EPYC 9004, 2x RTX 6000 Ada, 256GB ECC DDR5, 10Gbps Fiber.
   - **Enterprise Scale**: 4x AMD EPYC 9754, 4x NVIDIA H100, 2TB HBM, 100Gbps InfiniBand.
5. **AI Capabilities**: Real-time AFV (Audio Follows Video) Tracking, Self-Healing Calibration, 4D Depth Reconstruction.
6. **Financial Blueprint**:
   - **Module Cost**: ₹3.5L (Industrial Grade).
   - **Project Cost (PLF)**: ₹4.25Cr (113 Modules + Brain).
   - **OpEx per Show**: ₹15,000 (Scenario B Load).`,
          tools: [{ googleSearch: {} }],
        },
      });

      let fullResponse = '';
      processedTextRef.current = '';
      stopTTS();
      setStreamingMessage('');

      for await (const chunk of stream) {
        const chunkText = chunk.text || '';
        fullResponse += chunkText;
        setStreamingMessage(fullResponse);
        
        if (isHybridMode) {
          const remainingText = fullResponse.slice(processedTextRef.current.length);
          const sentenceEndMatch = remainingText.match(/[^.!?]+[.!?]/g);
          if (sentenceEndMatch) {
            for (const sentence of sentenceEndMatch) {
              queueTTS(sentence);
              processedTextRef.current += sentence;
            }
          }
        }
      }

      // Generate a creative title if this is the first message
      if (history.length <= 2) {
        try {
          const titleGen = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Generate a very short, creative title (max 4 words) for a chat that starts with this message: "${history[history.length - 1].content}". Respond ONLY with the title text, no quotes or punctuation.`,
          });
          const newTitle = titleGen.text?.trim();
          if (newTitle) {
            await updateDoc(doc(db, 'chats', activeChatId), {
              title: newTitle
            });
          }
        } catch (titleError) {
          console.error("Error generating title:", titleError);
        }
      }

      await addDoc(collection(db, 'chats', activeChatId, 'messages'), {
        role: 'bot',
        content: fullResponse,
        createdAt: serverTimestamp()
      });
      
      await updateDoc(doc(db, 'chats', activeChatId), {
        updatedAt: serverTimestamp()
      });

      if (isHybridMode && fullResponse.length > processedTextRef.current.length) {
        queueTTS(fullResponse.slice(processedTextRef.current.length));
      }

      setStreamingMessage(null);
    } catch (error: any) {
      console.error('Chat Error:', error);
      setIsLoading(false);
      setStreamingMessage(null);
      
      const errorMessage = error?.message || error?.toString() || "Unknown AI error";
      
      if (geminiManager.isQuotaError(error)) {
        geminiManager.markExhausted(apiKey);
        if (retryCount < 10) { 
          console.log(`Retrying chat request with new key unit (attempt ${retryCount + 1})...`);
          return generateAIResponse(history, activeChatId, retryCount + 1);
        }
      }

      setMessages(prev => [...prev, { 
        id: 'error-' + Date.now(), 
        role: 'bot', 
        content: `⚠️ **AI Connection Error:** ${errorMessage}\n\n${geminiManager.isQuotaError(error) ? 'This specific key unit is exhausted. Try sending your message again to rotate to a fresh unit.' : 'Please check your internet connection or try again.'}` 
      }]);
    }
  };

  // Handle clicks outside mic menu
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (micMenuRef.current && !micMenuRef.current.contains(event.target as Node)) {
        setIsMicMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Cleanup recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const playTTS = async (text: string) => {
    queueTTS(text);
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      console.error('Speech recognition not supported');
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      let transcript = event.results[0][0].transcript;
      // Fix common transcription error: Nephron -> Nefron
      transcript = transcript.replace(/nephron/gi, 'Nefron');
      setIsListening(false);
      handleSend(transcript);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const handleSend = async (overrideInput?: string) => {
    const messageToSend = overrideInput || input;
    if (!messageToSend.trim() || isLoading) return;

    let activeChatId = chatId;
    if (!activeChatId && onNewChat) {
      activeChatId = await onNewChat();
    }

    if (!activeChatId) return;

    const userMessage = messageToSend.trim();
    if (!overrideInput) setInput('');

    // Optimistic update to show user message immediately
    const tempId = 'temp-' + Date.now();
    const tempMsg = { id: tempId, role: 'user' as const, content: userMessage, createdAt: new Date() as any };
    setMessages(prev => [...prev, tempMsg]);
    messagesRef.current = [...messagesRef.current, tempMsg];
    
    try {
      await addDoc(collection(db, 'chats', activeChatId, 'messages'), {
        role: 'user',
        content: userMessage,
        createdAt: serverTimestamp()
      });
      
      // Use messagesRef to get the most up-to-date history
      const historyMessages = messagesRef.current.filter(m => m.id !== 'welcome' && !m.id.startsWith('temp-'));
      const updatedHistory = [...historyMessages, { id: 'temp', role: 'user' as const, content: userMessage }];
      generateAIResponse(updatedHistory, activeChatId);
    } catch (error) {
      console.error("Error sending message:", error);
      // Remove optimistic message on error
      setMessages(prev => prev.filter(m => m.id !== tempId));
      messagesRef.current = messagesRef.current.filter(m => m.id !== tempId);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] w-full bg-black-deep overflow-hidden">
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 md:p-12 space-y-8 scroll-smooth"
      >
        <div className="max-w-5xl mx-auto space-y-8">
          {messages.map((message) => (
            <div
              key={message.id}
              onMouseDown={() => startLongPress(message.id)}
              onMouseUp={cancelLongPress}
              onMouseLeave={cancelLongPress}
              onTouchStart={() => startLongPress(message.id)}
              onTouchEnd={cancelLongPress}
              onClick={() => handleClick(message.id)}
              onContextMenu={(e) => {
                if (isSelectionMode) e.preventDefault();
              }}
              className={cn(
                'flex items-start gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300 group cursor-pointer transition-all select-none',
                message.role === 'user' ? 'flex-row-reverse' : 'flex-row',
                isSelectionMode && selectedMessageIds.has(message.id) && 'opacity-100 scale-[1.02]',
                isSelectionMode && !selectedMessageIds.has(message.id) && 'opacity-50',
                editingMessageId === message.id && 'ring-2 ring-electric-blue ring-offset-4 ring-offset-black-deep rounded-2xl'
              )}
            >
              {isSelectionMode && (
                <div className="flex items-center self-center px-2">
                  {selectedMessageIds.has(message.id) ? (
                    <CheckSquare className="text-[var(--logo-gradient-start)]" size={24} />
                  ) : (
                    <Square className="text-muted opacity-50" size={24} />
                  )}
                </div>
              )}
              <div
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center shrink-0 shadow-lg',
                  message.role === 'user' 
                    ? 'bg-electric-blue/20 text-electric-blue border border-electric-blue/40 neon-glow' 
                    : 'bg-[var(--logo-gradient-start)]/30 text-[var(--logo-gradient-start)] border border-[var(--logo-gradient-start)]/50 neon-glow'
                )}
              >
                {message.role === 'user' ? <User size={20} /> : <Bot size={20} />}
              </div>
              <div
                className={cn(
                  'max-w-[85%] p-5 rounded-2xl text-base leading-relaxed shadow-md relative w-full',
                  message.role === 'user'
                    ? 'bg-electric-blue text-white rounded-tr-none neon-glow'
                    : 'bg-gray-dark/80 text-foreground border border-gray-dark rounded-tl-none'
                )}
              >
                {editingMessageId === message.id ? (
                  <div className="space-y-3">
                    <textarea
                      autoFocus
                      value={editingContent}
                      onChange={(e) => setEditingContent(e.target.value)}
                      className="w-full bg-black-deep/50 border border-white/20 rounded-lg p-3 text-white focus:outline-none focus:ring-1 focus:ring-white/40 resize-none min-h-[100px]"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          saveEdit();
                        }
                        if (e.key === 'Escape') {
                          setEditingMessageId(null);
                        }
                      }}
                    />
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingMessageId(null);
                        }}
                        className="px-3 py-1 rounded-lg text-xs font-bold hover:bg-white/10 transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          saveEdit();
                        }}
                        className="px-3 py-1 rounded-lg bg-white text-electric-blue text-xs font-bold hover:bg-white/90 transition-colors"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="prose prose-sm md:prose-base max-w-none prose-p:leading-relaxed prose-pre:bg-black-deep prose-pre:text-cyan-bright">
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{message.content}</ReactMarkdown>
                  </div>
                )}
              </div>
            </div>
          ))}

          {quotaError && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6 text-center animate-in fade-in slide-in-from-bottom-2 duration-500">
              <p className="text-red-500 text-xs font-bold uppercase tracking-widest mb-1 neon-glow">⚡ Firestore Quota Exceeded</p>
              <p className="text-muted text-[10px] sm:text-xs leading-relaxed max-w-sm mx-auto">
                You have reached your daily read limit for the free tier. 
                Your message history may be incomplete. Quota will reset at midnight.
              </p>
            </div>
          )}

          {streamingMessage !== null && (
            <div className="flex items-start gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300 flex-row">
              <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 shadow-lg bg-[var(--logo-gradient-start)]/30 text-[var(--logo-gradient-start)] border border-[var(--logo-gradient-start)]/50 neon-glow">
                <Bot size={20} />
              </div>
              <div className="max-w-[85%] p-5 rounded-2xl text-base leading-relaxed shadow-md relative w-full bg-gray-dark/80 text-foreground border border-gray-dark rounded-tl-none">
                <div className="prose prose-sm md:prose-base max-w-none prose-p:leading-relaxed prose-pre:bg-black-deep prose-pre:text-cyan-bright">
                  <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{streamingMessage}</ReactMarkdown>
                  {streamingMessage === '' && (
                    <div className="flex gap-1 mt-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-electric-blue animate-bounce [animation-delay:-0.3s]" />
                      <div className="w-1.5 h-1.5 rounded-full bg-electric-blue animate-bounce [animation-delay:-0.15s]" />
                      <div className="w-1.5 h-1.5 rounded-full bg-electric-blue animate-bounce" />
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          {isLoading && streamingMessage === null && (
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-full bg-[var(--logo-gradient-start)]/20 flex items-center justify-center border border-[var(--logo-gradient-start)]/30 neon-glow">
                <NefronLogo isThinking className="w-6 h-6" />
              </div>
              <div className="bg-gray-dark/80 p-4 rounded-2xl rounded-tl-none border border-gray-dark shadow-md">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-[var(--logo-gradient-start)] rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                  <span className="w-1.5 h-1.5 bg-[var(--logo-gradient-mid)] rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-1.5 h-1.5 bg-[var(--logo-gradient-end)] rounded-full animate-bounce"></span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-6 bg-black-deep border-t border-gray-dark/50 relative">
        <AnimatePresence>
          {isSelectionMode && (
            <motion.div
              initial={{ y: 100 }}
              animate={{ y: 0 }}
              exit={{ y: 100 }}
              className="absolute inset-x-0 bottom-full mb-6 flex justify-center px-4 z-50"
            >
              <div className="bg-gray-dark border border-gray-dark/50 rounded-2xl shadow-2xl p-4 flex flex-col sm:flex-row items-center gap-4 sm:gap-6 backdrop-blur-xl w-full max-w-md sm:max-w-none">
                <div className="flex flex-col items-center sm:items-start">
                  <span className="text-[10px] font-bold text-muted uppercase tracking-widest">Selection Mode</span>
                  <span className="text-sm font-bold text-foreground whitespace-nowrap">{selectedMessageIds.size} messages selected</span>
                </div>
                <div className="hidden sm:block h-8 w-px bg-gray-700/50" />
                <div className="flex flex-wrap sm:flex-nowrap items-center justify-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={() => {
                      if (selectedMessageIds.size === messages.length) {
                        setSelectedMessageIds(new Set());
                      } else {
                        setSelectedMessageIds(new Set(messages.map(m => m.id)));
                      }
                    }}
                    className="flex-1 sm:flex-none px-3 py-2 rounded-xl text-xs font-bold text-foreground hover:bg-black-deep transition-colors border border-foreground/10 whitespace-nowrap"
                  >
                    {selectedMessageIds.size === messages.length ? 'Deselect All' : 'Select All'}
                  </button>
                  <button
                    onClick={() => {
                      setIsSelectionMode(false);
                      setSelectedMessageIds(new Set());
                    }}
                    className="flex-1 sm:flex-none px-3 py-2 rounded-xl text-xs font-bold text-muted hover:bg-black-deep transition-colors whitespace-nowrap"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={deleteSelectedMessages}
                    disabled={selectedMessageIds.size === 0}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed font-bold text-xs"
                  >
                    <Trash2 size={16} />
                    Delete
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative flex items-center max-w-5xl mx-auto">
          {isListening && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="absolute -top-16 left-0 right-0 flex justify-center pointer-events-none"
            >
              <div className="bg-[var(--logo-gradient-start)] text-white px-6 py-2 rounded-full shadow-xl flex items-center gap-3 animate-pulse">
                <div className="flex gap-1">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: `${i * 0.1}s` }} />
                  ))}
                </div>
                <span className="text-sm font-bold tracking-wider">LISTENING...</span>
                <div className="flex items-center gap-2 ml-2 border-l border-white/20 pl-2">
                  <button 
                    onClick={() => {
                      setIsHybridMode(false);
                      setIsListening(false);
                      if (recognitionRef.current) recognitionRef.current.stop();
                      stopTTS();
                    }}
                    className="pointer-events-auto text-[10px] font-bold uppercase tracking-tighter hover:bg-white/20 px-2 py-1 rounded"
                  >
                    Exit
                  </button>
                  <button 
                    onClick={() => {
                      setIsListening(false);
                      if (recognitionRef.current) recognitionRef.current.stop();
                    }}
                    className="pointer-events-auto p-1 hover:bg-white/20 rounded-full"
                  >
                    <CloseIcon size={14} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={isHybridMode ? "Voice-to-Chat Mode Active..." : "Type your message..."}
            className={cn(
              "flex-1 bg-gray-dark border border-gray-dark/50 rounded-full py-4 px-8 pr-32 text-foreground focus:outline-none focus:ring-2 focus:ring-electric-blue focus:border-transparent transition-all shadow-inner placeholder:text-muted text-base",
              isHybridMode && "ring-2 ring-[var(--logo-gradient-start)]"
            )}
          />
          <div className="absolute right-3 flex items-center gap-2" ref={micMenuRef}>
            <div className="relative">
              <button
                onClick={async () => {
                  try {
                    // Request permission first to ensure user intent is captured
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    stream.getTracks().forEach(track => track.stop());
                    
                    if (isHybridMode && !isListening) {
                      startListening();
                    } else {
                      setIsMicMenuOpen(!isMicMenuOpen);
                    }
                  } catch (error) {
                    console.error("Microphone permission denied:", error);
                    // Still open the menu so user can see options, but they might fail later
                    setIsMicMenuOpen(!isMicMenuOpen);
                  }
                }}
                className={cn(
                  "p-2.5 rounded-full transition-all active:scale-90 neon-glow",
                  isHybridMode ? "bg-[var(--logo-gradient-start)] text-white" : "bg-gray-dark/40 border border-gray-dark/30 text-[var(--logo-gradient-mid)] hover:bg-gray-dark/80",
                  isListening && "animate-pulse ring-4 ring-[var(--logo-gradient-start)]/30"
                )}
              >
                <Mic size={20} />
              </button>

              <AnimatePresence>
                {isMicMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute bottom-full right-0 mb-4 w-64 bg-gray-dark border border-gray-dark/50 rounded-2xl shadow-2xl z-50 overflow-hidden"
                  >
                    <div className="p-2 space-y-1">
                      <button
                        onClick={() => {
                          setIsVoiceChatOpen(true);
                          setIsMicMenuOpen(false);
                          setIsHybridMode(false);
                        }}
                        className="w-full flex items-center gap-4 px-4 py-3 rounded-xl hover:bg-black-deep transition-colors text-left"
                      >
                        <div className="p-2 rounded-lg bg-gradient-to-br from-[var(--logo-gradient-start)] to-[var(--logo-gradient-end)] text-white">
                          <Headphones size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-foreground">Full Voice Chat</p>
                          <p className="text-[10px] text-muted uppercase tracking-wider">Immersive Experience</p>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          const newMode = !isHybridMode;
                          setIsHybridMode(newMode);
                          setIsMicMenuOpen(false);
                          if (!newMode) {
                            stopTTS();
                            setIsListening(false);
                          } else {
                            startListening();
                          }
                        }}
                        className={cn(
                          "w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-colors text-left",
                          isHybridMode ? "bg-[var(--logo-gradient-start)]/10" : "hover:bg-black-deep"
                        )}
                      >
                        <div className={cn(
                          "p-2 rounded-lg text-white",
                          isHybridMode ? "bg-[var(--logo-gradient-start)]" : "bg-gray-dark border border-gray-700"
                        )}>
                          <MessageSquare size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-foreground">Chated Voice</p>
                          <p className="text-[10px] text-muted uppercase tracking-wider">Voice-to-Text Hybrid</p>
                        </div>
                        {isHybridMode && <div className="ml-auto w-2 h-2 rounded-full bg-[var(--logo-gradient-start)] animate-pulse" />}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              style={{ 
                background: `linear-gradient(135deg, var(--btn-bg-start), var(--btn-bg-mid), var(--btn-bg-end))`,
                color: 'var(--btn-text)'
              }}
              className="p-2.5 rounded-full transition-all duration-300 active:scale-90 neon-glow-intense scale-110"
            >
              <Send size={22} strokeWidth={3} className="drop-shadow-[0_0_2px_rgba(255,255,255,0.3)]" />
            </button>
          </div>
        </div>
        <p className="text-center text-[10px] text-muted mt-4 uppercase tracking-widest opacity-50">
          Nefron AI can make mistakes. Check important info.
        </p>
      </div>

      <VoiceChat 
        isOpen={isVoiceChatOpen} 
        onClose={() => setIsVoiceChatOpen(false)} 
      />
    </div>
  );
}
