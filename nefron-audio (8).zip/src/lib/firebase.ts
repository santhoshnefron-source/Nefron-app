import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, User, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { initializeFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Explicitly set persistence to local to ensure sessions are saved across reloads in iframes
setPersistence(auth, browserLocalPersistence).catch((error) => {
  console.error("Auth persistence error:", error);
});

// Use initializeFirestore with settings to handle potential proxy/network restrictions
// Forcing Long Polling is often required for sites hosted on Netlify/Vercel to avoid connection errors
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
}, firebaseConfig.firestoreDatabaseId === '(default)' ? undefined : firebaseConfig.firestoreDatabaseId);

export const googleProvider = new GoogleAuthProvider();

// Test connection with retry logic
async function testConnection(retries = 3) {
  try {
    // Attempt a lightweight server fetch
    await getDocFromServer(doc(db, 'system', 'health'));
    console.log("Firebase Connectivity: Online");
  } catch (error: any) {
    if (retries > 0) {
      console.warn(`Firebase Connection attempt failed. Retrying... (${retries} left)`);
      setTimeout(() => testConnection(retries - 1), 2000);
      return;
    }
    
    console.group("Firebase Connection Debug");
    console.error("Status: Offline / Error");
    console.error("Message:", error?.message);
    console.error("Code:", error?.code);
    console.groupEnd();
    
    if (error?.message?.includes('the client is offline')) {
      // This is a common issue on certain networks or if long-polling isn't enough
      console.error("Recommendation: Ensure your firewall or browser is not blocking Firebase WebSockets/Long-polling.");
    }
  }
}
testConnection();

export { signInWithPopup, onAuthStateChanged };
export type { User };
