'use client';

import * as React from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence, useMotionValue, animate } from 'motion/react';
import { Upload, X, Image as ImageIcon, Trash2, Sparkles, Loader2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { NefronLogo } from './icons';
import { db, auth } from '../lib/firebase';
import { doc, onSnapshot, setDoc, serverTimestamp } from 'firebase/firestore';
import { AboutAiGuide } from './about-ai-guide';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const FullScreenOverlay = React.memo(({ src, onClose }: { src: string | null, onClose: () => void }) => {
  const [scale, setScale] = React.useState(1);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const lastTap = React.useRef<number>(0);
  const containerRef = React.useRef<HTMLDivElement>(null);

  const handleImageClick = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    const now = Date.now();
    
    // Get coordinates
    let clientX = 0;
    let clientY = 0;
    
    if ('clientX' in e) {
      clientX = e.clientX;
      clientY = e.clientY;
    } else if ('changedTouches' in e && e.changedTouches.length > 0) {
      clientX = e.changedTouches[0].clientX;
      clientY = e.changedTouches[0].clientY;
    }

    if (now - lastTap.current < 400) {
      // Double tap detected
      if (scale > 1) {
        setScale(1);
        animate(x, 0, { type: "spring", stiffness: 400, damping: 40 });
        animate(y, 0, { type: "spring", stiffness: 400, damping: 40 });
      } else {
        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight / 2;
        
        // Calculate how much to shift to center the tapped point
        const dx = (centerX - clientX) * 2;
        const dy = (centerY - clientY) * 2;
        
        setScale(2);
        animate(x, dx, { type: "spring", stiffness: 400, damping: 40 });
        animate(y, dy, { type: "spring", stiffness: 400, damping: 40 });
      }
    }
    lastTap.current = now;
  };

  // Reset scale and position when image changes or closes
  React.useEffect(() => {
    if (!src) {
      setScale(1);
      x.set(0);
      y.set(0);
    }
  }, [src, x, y]);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <AnimatePresence>
      {src && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.1, ease: "linear" }}
          className="fixed inset-0 z-[9999] bg-black flex items-center justify-center overflow-hidden touch-none"
          style={{ transform: 'translateZ(0)', backfaceVisibility: 'hidden' }}
          onClick={onClose}
        >
          <button
            className="absolute top-6 right-6 p-3 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors z-[10000] focus:outline-none"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
          >
            <X size={24} />
          </button>

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md text-white/60 text-[10px] font-bold uppercase tracking-[0.2em] pointer-events-none select-none z-[10000]">
            {scale > 1 ? "Drag to pan • Double tap to reset" : "Double tap to zoom"}
          </div>

          <div 
            ref={containerRef}
            className="relative w-full h-full flex items-center justify-center"
            onClick={handleImageClick}
            onTouchEnd={handleImageClick}
          >
            <motion.img
              drag={scale > 1}
              dragConstraints={{ 
                left: -1200, 
                right: 1200, 
                top: -1200, 
                bottom: 1200 
              }}
              dragElastic={0.1}
              style={{ x, y, scale }}
              animate={{ scale }}
              transition={{ type: "spring", stiffness: 400, damping: 40 }}
              whileTap={{ scale: scale > 1 ? 0.98 : 1.02 }}
              src={src}
              alt="Full Screen Preview"
              className={cn(
                "max-w-full max-h-screen object-contain select-none",
                scale > 1 ? "cursor-grab active:cursor-grabbing" : "cursor-zoom-in"
              )}
              referrerPolicy="no-referrer"
              decoding="async"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
});

FullScreenOverlay.displayName = 'FullScreenOverlay';

export function AboutPage() {
  const [images, setImages] = React.useState<{ [key: string]: string | null }>({});
  const [loadingStates, setLoadingStates] = React.useState<{ [key: string]: boolean }>({
    main: true, theater: true, music: true, tilt: true,
    f1: true, f2: true, f3: true, f4: true, f5: true, f6: true,
    nefronAudio: true
  });
  const [uploadingStates, setUploadingStates] = React.useState<{ [key: string]: boolean }>({});

  const [fullScreenImage, setFullScreenImage] = React.useState<string | null>(null);
  const [, startTransition] = React.useTransition();

  const handleZoom = React.useCallback((src: string | null) => {
    startTransition(() => {
      setFullScreenImage(src);
    });
  }, []);

  React.useEffect(() => {
    const configs = [
      { id: 'about_page', key: 'main', field: 'image' },
      { id: 'about_page_theater', key: 'theater', field: 'theaterImage' },
      { id: 'about_page_music_mode', key: 'music', field: 'musicModeImage' },
      { id: 'about_page_tilt', key: 'tilt', field: 'tiltImage' },
      { id: 'about_page_feature_one', key: 'f1', field: 'featureOneImage' },
      { id: 'about_page_feature_two', key: 'f2', field: 'featureTwoImage' },
      { id: 'about_page_feature_three', key: 'f3', field: 'featureThreeImage' },
      { id: 'about_page_feature_four', key: 'f4', field: 'featureFourImage' },
      { id: 'about_page_feature_five', key: 'f5', field: 'featureFiveImage' },
      { id: 'about_page_feature_six', key: 'f6', field: 'featureSixImage' },
      { id: 'about_page_nefron_audio', key: 'nefronAudio', field: 'nefronAudioImage' },
    ];

    const unsubscribes = configs.map(config => {
      return onSnapshot(doc(db, 'app_settings', config.id), (snap) => {
        setImages(prev => ({ ...prev, [config.key]: snap.exists() ? snap.data()[config.field] : null }));
        setLoadingStates(prev => ({ ...prev, [config.key]: false }));
      }, (error) => {
        handleFirestoreError(error, OperationType.GET, `app_settings/${config.id}`);
        setLoadingStates(prev => ({ ...prev, [config.key]: false }));
      });
    });

    return () => unsubscribes.forEach(unsub => unsub());
  }, []);

  const isAdmin = React.useMemo(() => {
    const email = auth.currentUser?.email;
    return email === 'p26893150@gmail.com';
  }, [auth.currentUser?.email]);

  const setUploading = (key: string, value: boolean) => {
    setUploadingStates(prev => ({ ...prev, [key]: value }));
  };

  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const theaterFileInputRef = React.useRef<HTMLInputElement>(null);
  const musicModeFileInputRef = React.useRef<HTMLInputElement>(null);
  const tiltFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureOneFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureTwoFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureThreeFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureFourFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureFiveFileInputRef = React.useRef<HTMLInputElement>(null);
  const featureSixFileInputRef = React.useRef<HTMLInputElement>(null);
  const nefronAudioFileInputRef = React.useRef<HTMLInputElement>(null);

  const configMap: { [key: string]: { id: string, field: string, ref: React.RefObject<HTMLInputElement | null> } } = {
    main: { id: 'about_page', field: 'image', ref: fileInputRef },
    theater: { id: 'about_page_theater', field: 'theaterImage', ref: theaterFileInputRef },
    music: { id: 'about_page_music_mode', field: 'musicModeImage', ref: musicModeFileInputRef },
    tilt: { id: 'about_page_tilt', field: 'tiltImage', ref: tiltFileInputRef },
    f1: { id: 'about_page_feature_one', field: 'featureOneImage', ref: featureOneFileInputRef },
    f2: { id: 'about_page_feature_two', field: 'featureTwoImage', ref: featureTwoFileInputRef },
    f3: { id: 'about_page_feature_three', field: 'featureThreeImage', ref: featureThreeFileInputRef },
    f4: { id: 'about_page_feature_four', field: 'featureFourImage', ref: featureFourFileInputRef },
    f5: { id: 'about_page_feature_five', field: 'featureFiveImage', ref: featureFiveFileInputRef },
    f6: { id: 'about_page_feature_six', field: 'featureSixImage', ref: featureSixFileInputRef },
    nefronAudio: { id: 'about_page_nefron_audio', field: 'nefronAudioImage', ref: nefronAudioFileInputRef },
  };

  const handleGenericUpload = async (key: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && isAdmin) {
      setUploading(key, true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          let base64String = reader.result as string;
          if (file.size > 750 * 1024) base64String = await compressImage(base64String);
          const config = configMap[key];
          await setDoc(doc(db, 'app_settings', config.id), { [config.field]: base64String, updatedAt: serverTimestamp() });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `app_settings/${configMap[key].id}`);
        } finally {
          setUploading(key, false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImageByKey = async (key: string, id: string) => {
    if (!isAdmin) return;
    try {
      setUploading(key, true);
      const field = configMap[key].field;
      await setDoc(doc(db, 'app_settings', id), { [field]: null, updatedAt: serverTimestamp() });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `app_settings/${id}`);
    } finally {
      setUploading(key, false);
    }
  };

  const ImageHolder = React.memo(({ 
    imageKey, 
    title, 
    placeholder, 
    alt 
  }: { 
    imageKey: string, 
    title: string, 
    placeholder: string, 
    alt: string 
  }) => {
    const img = images[imageKey];
    const loading = loadingStates[imageKey];
    const uploading = uploadingStates[imageKey];
    const config = configMap[imageKey];

    return (
      <div className="space-y-6 mt-8">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-muted flex items-center gap-2">
            <Sparkles size={16} className="text-electric-blue" />
            {title}
          </h2>
          {img && isAdmin && (
            <button
              onClick={() => clearImageByKey(imageKey, config.id)}
              disabled={uploading}
              className="text-xs font-bold uppercase tracking-widest text-red-500 hover:text-red-400 transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              {uploading ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
              Remove Image
            </button>
          )}
        </div>

        <div className={cn(
          "relative group rounded-3xl overflow-hidden border-2 border-dashed transition-all duration-500 min-h-[300px] flex items-center justify-center",
          img ? "border-electric-blue/30 shadow-2xl shadow-electric-blue/10" : "border-foreground/10 hover:border-electric-blue/50 bg-gray-dark/30",
          !isAdmin && !img && "border-none bg-transparent"
        )}>
          {isAdmin && (
            <input
              type="file"
              ref={config.ref}
              onChange={(e) => handleGenericUpload(imageKey, e)}
              accept="image/*"
              className="hidden"
            />
          )}

          <div className="w-full h-full flex items-center justify-center">
            {loading ? (
              <Loader2 className="w-8 h-8 text-electric-blue animate-spin" />
            ) : img ? (
              <motion.div 
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                className="w-full relative cursor-zoom-in group/img" 
                onClick={() => handleZoom(img)}
              >
                <img src={img} alt={alt} className="w-full h-auto block transition-transform duration-500 group-hover/img:scale-[1.02] will-change-transform" referrerPolicy="no-referrer" />
                
                {/* Hover Overlay for all users to indicate zoomability */}
                <div className="absolute inset-0 bg-black/0 group-hover/img:bg-black/20 transition-colors duration-300 flex items-center justify-center">
                  <div className="p-3 rounded-full bg-white/10 backdrop-blur-md text-white opacity-0 group-hover/img:opacity-100 transition-all duration-300 transform scale-90 group-hover/img:scale-100">
                    <Sparkles size={24} className="animate-pulse" />
                  </div>
                </div>

                {isAdmin && (
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-3">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        config.ref.current?.click();
                      }} 
                      disabled={uploading} 
                      className="px-6 py-3 rounded-full bg-white text-black font-bold text-sm flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 disabled:opacity-50 hover:bg-electric-blue hover:text-white"
                    >
                      {uploading ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />}
                      Change Image
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleZoom(img);
                      }}
                      className="px-6 py-3 rounded-full bg-black/50 border border-white/30 text-white font-bold text-sm flex items-center gap-2 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-75 hover:bg-white/20"
                    >
                      <Sparkles size={18} />
                      View Full Screen
                    </button>
                  </div>
                )}
              </motion.div>
            ) : isAdmin ? (
              <div className="w-full h-full flex flex-col items-center justify-center gap-4 cursor-pointer py-12" onClick={() => config.ref.current?.click()}>
                <div className="w-16 h-16 rounded-full bg-electric-blue/10 flex items-center justify-center text-electric-blue group-hover:scale-110 transition-transform duration-500">
                  {uploading ? <Loader2 size={32} className="animate-spin" /> : <ImageIcon size={32} />}
                </div>
                <div className="text-center">
                  <p className="text-lg font-medium text-foreground">{placeholder}</p>
                  <p className="text-sm text-muted">Click to select a visualization</p>
                </div>
              </div>
            ) : (
              <div className="text-muted italic text-sm">No visualization set by administrator.</div>
            )}
          </div>
        </div>
      </div>
    );
  });

  const compressImage = (base64Str: string, maxWidth = 2560, maxHeight = 2560, quality = 0.9): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height *= maxWidth / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width *= maxHeight / height;
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
    });
  };

  const mainContent = React.useMemo(() => (
    <div className="max-w-3xl w-full space-y-12">
      {/* Header Section */}
        <div className="text-center space-y-4">
          <motion.div
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center justify-center pt-8 md:pt-12"
          >
            <NefronLogo className="w-24 h-24 md:w-32 md:h-32 mx-auto mb-8 opacity-90 drop-shadow-[0_0_15px_rgba(57,255,20,0.3)]" />
          </motion.div>
          <h1 className="text-4xl md:text-5xl font-headline tracking-widest neon-glow bg-gradient-to-r from-[var(--logo-gradient-start)] via-[var(--logo-gradient-mid)] to-[var(--logo-gradient-end)] bg-clip-text text-transparent">
            About Nefron
          </h1>
          <div className="h-px w-32 mx-auto bg-gradient-to-r from-transparent via-electric-blue/50 to-transparent" />
        </div>

        {/* Story Section */}
        <div id="nefron-audio" className="space-y-10 text-left performance-section">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold text-electric-blue tracking-wider uppercase">NEFRON AUDIO</h2>
            <p className="text-xl font-medium text-foreground">The World's First Electro-Mechanical Spatial Audio Platform</p>
            <p className="text-sm text-muted italic">Founded by Santhosh</p>
            
            <ImageHolder 
              imageKey="nefronAudio"
              title="Nefron Audio Visualization"
              placeholder="Upload Nefron Audio Visualization"
              alt="Nefron Audio"
            />
          </div>

          <section id="story-sound" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              THE STORY OF SOUND — AND WHY IT NEEDED TO CHANGE
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              For decades, the cinema industry has chased one singular goal: to make audiences forget they are sitting in a room and feel like they are living inside the story. Every generation of audio technology has brought us closer to that dream. But until today, one fundamental physical problem has remained unsolved.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This is the story of how Nefron Audio solved it.
            </p>
          </section>

          <section id="dolby-atmos" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              UNDERSTANDING DOLBY ATMOS — THE CURRENT GOLD STANDARD
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              To appreciate what Nefron Audio has achieved, you must first understand what came before it.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Dolby Atmos, introduced in 2012, was a genuine revolution in cinematic sound. Before Atmos, audio was "channel-based" — meaning sound was rigidly locked to specific speakers around the room. If an explosion happened on screen, the left speaker played loudly and the right speaker played quietly. The movement was crude and mechanical.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Dolby Atmos changed this by introducing "object-based audio." Instead of assigning sound to a channel, Atmos treats every sound as a moving object with real coordinates in three-dimensional space. A helicopter flying overhead is no longer just "the ceiling speaker playing" — it is a data point with X, Y, and Z coordinates that the system tries to recreate using whatever speakers are available in the room.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This was a massive leap forward. Atmos brought Hollywood-quality immersive audio to cinemas around the world and became the undisputed industry standard. Today, over 10,000 screens globally are Atmos-certified, and virtually every major blockbuster is mixed in Atmos.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              It is the best spatial audio system ever built.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              And it still has a fundamental, unsolvable problem.
            </p>
          </section>

          <section id="limitations" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              THE LIMITATION THAT DOLBY ATMOS CANNOT FIX
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              Here is the core issue. Dolby Atmos is brilliant software running on flawed hardware.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              No matter how sophisticated the object-based audio metadata is, the sound still has to come out of a physical speaker that is bolted to a fixed position on the wall. And this creates what acoustic engineers call the "Sweet Spot Problem."
            </p>
            <p className="text-muted leading-relaxed text-lg">
              To understand it, imagine a car moving from left to right across the cinema screen. In a Dolby Atmos theater, this effect is created by a process called amplitude panning — the system gradually increases the volume on the right side speakers while decreasing it on the left side speakers. For the person sitting perfectly in the center of the theater, their brain combines these two signals and perceives the sound as smoothly moving from left to right.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              But here is the brutal physical truth: only the person in the exact center of the room experiences this correctly.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              For a person sitting near the left wall, the left speaker is physically much closer to their ears. Sound travels at 343 meters per second. The left speaker's sound arrives at their ear milliseconds before the right speaker's sound does. The human brain has a built-in survival mechanism called the Precedence Effect — it automatically trusts the first sound that arrives and ignores the later one. This means the person near the left wall does not hear a car smoothly moving across the screen. They hear a car that stays on the left side and then suddenly jumps to the right. The smooth motion completely breaks down.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This is not a software problem. This is not a mixing problem. This is a fundamental law of physics — the Inverse Square Law — which states that sound intensity drops exponentially with distance. No software update, no DSP algorithm, and no amount of additional speakers can fully overcome this physical reality as long as the speakers themselves are fixed and stationary.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              In a standard multiplex with 300 seats, perhaps 30 to 50 people sitting in the center "sweet zone" experience the full premium Dolby Atmos experience. The remaining 250 people — who paid the same premium ticket price — receive a compromised version of that experience, even though the theater spent crores installing a world-class system.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Furthermore, Dolby Atmos has a hard technical ceiling of 128 simultaneous audio objects. In a complex cinematic scene with rain, multiple characters speaking, vehicles, explosions, and ambient sounds, the system is forced to compress and combine multiple sound sources into single objects. Nuance is lost. Detail disappears. The mix that the sound engineer crafted in the studio does not fully survive the journey to the listener's ears.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              And finally, every Dolby Atmos installation requires days of manual calibration by certified engineers, and every film mixed in Atmos requires extensive, expensive post-production work where sound engineers manually input spatial coordinates frame by frame for every audio object.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              These are not minor inconveniences. They are structural limitations built into the very foundation of how fixed-speaker spatial audio works. And for thirteen years, the entire industry accepted them as unavoidable.
            </p>
            <p className="text-muted leading-relaxed text-lg font-bold text-foreground italic">
              Santhosh did not accept them.
            </p>
          </section>

          <section id="intro-nefron" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              INTRODUCING NEFRON AUDIO — SOUND THAT PHYSICALLY MOVES
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              Nefron Audio is not an upgrade to Dolby Atmos. It is not a better version of the same idea. It is a completely different idea built on a completely different physical principle.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The insight at the heart of Nefron Audio is simple but profound:
            </p>
            <p className="text-muted leading-relaxed text-xl font-bold text-electric-blue">
              If the problem is that fixed speakers cannot follow sound objects through space, then the solution is to build speakers that are not fixed.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Every speaker in the Nefron Audio system is physically capable of rotating. Not electronically simulating rotation. Not digitally panning between channels. Actually, mechanically rotating — pointing its acoustic energy in the precise direction the sound needs to travel, in real time, following every moving object on screen.
            </p>
            <p className="text-muted leading-relaxed text-lg font-bold text-foreground">
              This single idea changes everything.
            </p>
          </section>
        </div>

        {/* Technical Specifications Section */}
        <div id="technical-specs" className="space-y-12 text-left performance-section">
          <section id="nefron-module" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              THE NEFRON MODULE — ENGINEERING A NEW KIND OF SPEAKER
            </h3>

            {/* Image Holder Section */}
            <ImageHolder 
              imageKey="main"
              title="Module Visualization"
              placeholder="Upload Module Visualization"
              alt="About Nefron"
            />

            <p className="text-muted leading-relaxed text-lg mt-6">
              The fundamental physical unit of the Nefron Audio system is called a Module. Understanding the module is the key to understanding the entire system.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Each Nefron Module is a precision-engineered acoustic panel measuring approximately 1.06 meters wide by 1.15 meters tall and 22 centimeters deep. From the outside, it appears as a sleek, uniform panel mounted flush against the theater wall. But inside, it contains a sophisticated combination of acoustic and mechanical engineering unlike anything in the current market.
            </p>
          </section>

          <section id="rotating-drivers" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Rotating Drivers</h4>
            <p className="text-muted leading-relaxed text-lg">
              At the heart of each module is a 3x3 grid of nine individual Drivers — high-performance 165mm (6.5 inch) mid-to-high frequency speakers, each rated at 150 watts RMS. But these are not ordinary speakers. Every single one of the nine drivers is mounted on its own independent micro-gimbal system driven by two precision stepper motors.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The first motor controls horizontal rotation. The second motor controls vertical tilt. Together, they give each driver a full 0 to 180 degree range of physical motion on both axes. This means each driver can physically aim its acoustic energy at any point in the room — like a spotlight that tracks a performer on stage, except this spotlight is made of sound.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              When an audio object moves across the screen — a spaceship, a voice, a musical instrument — the Nefron system does not increase the volume on one side and decrease it on the other. Instead, the relevant drivers physically rotate to follow the object's trajectory. The acoustic energy is not faked. It is not an illusion. It is a real, physical sound wave being emitted from a real speaker that is genuinely pointing in the direction of the sound.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The difference in perceived audio quality is not subtle. It is the difference between seeing a painting of a fire and sitting next to one.
            </p>
          </section>

          <section id="woofer-subwoofer" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Woofer and Subwoofer Architecture</h4>
            <p className="text-muted leading-relaxed text-lg">
              Each module is completed by additional transducers strategically positioned to maximize acoustic performance. However, not every module in the theater is identical — the Nefron system uses two distinct module configurations depending on the row position, each engineered for a specific acoustic purpose.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              In the first and second rows, each module is equipped with a 12-inch Mid-Bass Woofer rated at 500 watts RMS at both the top and the bottom of the driver array. These dual woofers handle the mid-bass frequency range from 80 Hz to 250 Hz — the range responsible for the "punch" and "impact" in cinematic explosions, punches, and deep voices. The dual woofer configuration in these rows ensures maximum mid-bass projection across the full vertical spread of the audience seating, delivering consistent impact energy to every row from front to back.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              In the third and final row — the foundation row positioned closest to the floor — the configuration changes deliberately. A 12-inch Mid-Bass Woofer rated at 500 watts RMS is retained at the top, while the bottom position is occupied by an 18-inch Subwoofer rated at 1000 watts RMS, physically coupled directly to the floor. This is not an accident of design — it is a deliberate application of acoustic boundary physics. When a subwoofer is placed directly at the intersection of the wall and the floor, it achieves what engineers call "eighth-space loading." The floor and wall surfaces act as acoustic mirrors, effectively quadrupling the low-frequency output efficiency of the speaker without requiring any additional amplifier power. Ultra-low frequencies travel through the structure of the building itself, through the seats, and directly into the bodies of the audience through bone conduction. The result is bass that you do not just hear — you feel in your chest, your spine, and your seat. This is the physical mechanism that makes a Nefron Audio theater feel genuinely different from any other theater experience in the world.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The total acoustic output of a single standard module (Rows 1 and 2) is approximately 2,350 watts RMS, while a foundation module (Row 3) delivers approximately 2,850 watts RMS, with a peak instantaneous draw of approximately 4.5 kilowatts during high-intensity cinematic sequences.
            </p>
          </section>

          <section id="theater-layout" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              THE THEATER LAYOUT — A DOME OF INTELLIGENT SOUND
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              One Nefron Module is impressive engineering. But the true power of the system emerges when you understand how hundreds of modules work together to transform an entire cinema into a unified, intelligent acoustic environment.
            </p>
          </section>

          <section id="theater-layout-viz" className="space-y-4">
            <ImageHolder 
              imageKey="theater"
              title="Theater Layout Visualization"
              placeholder="Upload Theater Layout"
              alt="Theater Layout"
            />
          </section>

          <section id="diamond-array" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Staggered Diamond Array</h4>
            <p className="text-muted leading-relaxed text-lg">
              Nefron modules are installed across all four surfaces of the cinema interior — both side walls, the rear wall, and the ceiling. They are never installed as a simple flat grid. Instead, they follow a precisely calculated three-row staggered diamond pattern that eliminates every acoustic dead zone in the room.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              In this arrangement, the first row and third row of modules are aligned vertically with each other. The second row — the middle row — is offset horizontally, positioning each of its modules directly in the center of the gap between two modules in the rows above and below it. When viewed from above, the modules form a continuous interlocking diamond pattern across every surface.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This staggering is not aesthetic. It is acoustically critical. It ensures that as a sound object moves along any trajectory — left to right, front to back, floor to ceiling — it is always within the optimal dispersion range of at least one driver. There are no gaps, no shadows, no dead zones where the sound illusion breaks down.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The mathematical formula governing this layout is elegantly simple. For any given wall length, the number of modules per standard row is calculated as the floor of the quantity (wall length plus 2.5 meters) divided by 3.56 meters. The total number of modules per wall surface equals three times this base row count, minus one, to account for the offset middle row. For a standard PLF theater measuring 40 meters long and 20 meters wide, this formula yields exactly 113 modules covering all four surfaces — containing 1,017 independently rotating drivers and 2,034 precision stepper motors, all controlled simultaneously by a single unified AI system.
            </p>
          </section>

          <section id="music-mode-viz" className="space-y-4">
            <ImageHolder 
              imageKey="music"
              title="Music Mode Visualization"
              placeholder="Upload Music Mode Visualization"
              alt="Music Mode Visualization"
            />
          </section>

          <section id="music-mode" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Intelligent Driver Assignment System — Music Mode</h4>
            <p className="text-muted leading-relaxed text-lg">
              One of the most breathtaking capabilities of the Nefron Audio platform is the way it transforms a cinematic musical sequence into something that has never existed inside a theater before — a fully surrounding, physically present live performance. To understand how this works, you must first understand that every driver in the Nefron system is individually addressable, meaning the central AI can send a completely different audio signal to every single one of the 1,017 drivers in the theater simultaneously, with each driver physically aimed in its own independent direction.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              When a song begins in a film, the Nefron system does not simply play stereo music through surrounding speakers the way every other cinema system in history has done. Instead, it intelligently separates every element of the musical mix and assigns each element to a specific physical driver in a specific location in the room, creating an acoustic map of the performance that surrounds the audience on all sides.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The lead vocal — the primary human voice carrying the melody — is assigned exclusively to the five <strong>center drivers</strong> of each module across the entire theater. In the five-module reference arrangement, these are Driver 5 in the top-left module, Driver 14 in the top-right module, Driver 23 in the center module, Driver 32 in the bottom-left module, and Driver 41 in the bottom-right module. Because these five center drivers are distributed across all surfaces of the theater — side walls, rear wall, and ceiling — every single audience member, regardless of which seat they occupy, has a center driver physically aimed directly toward them. The vocal does not come from the front of the room. It does not come from one side. It arrives from the nearest center driver on whichever surface faces that particular seat. For every person in the theater, the lead voice feels intimate, direct, and personally present — as though the performer is standing a few feet away and singing specifically to them.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              As the musical arrangement builds and the chorus swells, the system introduces the next acoustic layer using a principle borrowed from the physics of fluid dynamics. The chorus voices and harmonic layers are assigned to the ring of drivers immediately surrounding the center driver of the primary module — specifically Drivers 19, 20, 21, 22, 24, 25, 26, and 27 surrounding Driver 23. As the chorus grows in intensity, the audio ripples outward from the center driver to the surrounding ring, and then continues expanding to the peripheral drivers beyond that ring. The acoustic effect this creates is precisely analogous to dropping a stone into still water and watching the ripple rings expand outward in perfect concentric circles. The chorus does not simply get louder — it physically grows larger, expanding its spatial presence across the wall surface as the musical intensity increases, and then receding back toward the center as the chorus ends. The audience perceives this not as a volume change but as a spatial event — the sound itself expanding and contracting like a breathing organism.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The remaining drivers — every driver across all modules that is not a designated center driver — are then assigned to the individual instruments of the musical arrangement. Each driver receives exactly one instrument. If the recording features a five-piece drum kit, five separate drivers in different physical locations each receive one drum. If the arrangement includes acoustic guitar, electric bass, piano, strings, brass, and synthesizer, each of those instruments occupies its own dedicated driver in its own specific position in the room. Because the drivers are distributed across the side walls, rear wall, and ceiling in a continuous staggered array, these instruments appear to the audience as physically present sound sources surrounding them from all directions — the guitar to the left, the piano above and behind, the strings wrapping around the right side, the bass physically felt through the floor.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The consequence of this architecture is an acoustic experience that no recording technology has ever previously been able to deliver inside a cinema or any enclosed space. When a person attends a live orchestral performance, the reason it feels so profoundly different from any recording is that every instrument occupies its own unique point in three-dimensional space, and every sound wave arrives at the listener's ear from a distinct physical direction. The brain processes these individual directional signals separately, creating a sense of acoustic depth, space, and presence that blended speaker playback permanently destroys. Nefron Audio reconstructs this physical reality inside the theater. Every instrument is once again a distinct, localized, physically present sound source. The blend is gone. The compression is gone. What remains is the closest approximation to being physically present inside a live performance that technology has ever achieved — not through digital simulation, but through the deliberate, intelligent, physical placement of real acoustic energy in real space around a real human being sitting in a cinema seat.
            </p>
          </section>

          <section id="tilt-architecture" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Tilt Architecture</h4>
            
            <ImageHolder 
              imageKey="tilt"
              title="Tilt Architecture Visualization"
              placeholder="Upload Tilt Architecture Visualization"
              alt="Tilt Architecture Visualization"
            />

            <p className="text-muted leading-relaxed text-lg">
              One additional installation detail separates Nefron from any conventional speaker placement approach. Rather than mounting modules at 90 degrees flush against the wall — which is the standard for all current cinema audio systems — Nefron modules are angled at 30 to 45 degrees inward toward the seating area.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This inward tilt solves three acoustic problems simultaneously. First, it dramatically reduces early reflections — the immediate bouncing of sound off the adjacent wall surface, which smears the clarity of dialogue and musical detail. Second, it places the majority of the audience within the on-axis dispersion window of the mid-to-high frequency drivers, ensuring every seat receives the full frequency spectrum rather than an off-axis roll-off. Third, it redistributes acoustic pressure across the seating rows, preventing the rear seats from receiving an uncomfortably loud blast from the rear wall modules.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The ceiling modules are angled 45 degrees downward toward the audience. The rear wall modules are angled 15 to 20 degrees forward. Together, this precisely calculated angular architecture creates what can best be described as a Sonic Canopy — a continuous, curved dome of acoustically active surfaces that wraps around every seat in the theater with equal intensity and clarity.
            </p>
          </section>

          <section id="features" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              SIX REVOLUTIONARY FEATURES OF NEFRON AUDIO
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              Beyond the fundamental breakthrough of physical acoustic steering, the Nefron Audio platform introduces six additional capabilities that collectively define an entirely new category of cinematic audio.
            </p>
          </section>

          <section id="feature-1" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature One — The Live Orchestra Effect</h4>
            <ImageHolder 
              imageKey="f1"
              title="Feature One Visualization"
              placeholder="Upload Feature One Visualization"
              alt="Feature One Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              When you attend a live orchestral performance, you do not hear a wall of blended sound. You hear each instrument coming from its own distinct physical location in space. The violin section is to your left. The brass is in the center rear. The percussion is far to the right. Each sound wave reaches your ear as a separate, independent signal, and your brain processes them individually. This is why live music feels so dramatically more vivid and three-dimensional than recorded music played through conventional speakers.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The Nefron Audio system replicates this physical reality. Because every driver is independently addressable, the system's digital signal processor can isolate the individual stems of the audio mix — vocals, guitar, piano, drums, violin, brass — and route each one to a dedicated physical driver in a specific location in the room. When a drummer uses five drums in a recording session, the Nefron system can assign each of those five drums to five separate drivers in different parts of the theater. The audience does not just hear "drum sounds from the speakers." They hear five distinct drums, each physically located in a different corner of their acoustic environment, with every subtle timing and tonal difference between them preserved and spatially reproduced.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The result is a listening experience that has never existed in a cinema before — a full live-performance acoustic environment that surrounds the audience on all sides, with every instrument present as a distinct, physically localized sound source.
            </p>
          </section>

          <section id="feature-2" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature Two — Psychoacoustic Emotional Engineering</h4>
            <ImageHolder 
              imageKey="f2"
              title="Feature Two Visualization"
              placeholder="Upload Feature Two Visualization"
              alt="Feature Two Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              Human beings do not merely hear sound. They feel it. Certain frequencies interact directly with the body's biological systems, bypassing conscious cognition entirely and triggering instinctive emotional and physiological responses. Nefron Audio is the first cinema audio platform explicitly designed to harness this biological reality.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              For horror and suspense sequences, the system can deploy infrasonic frequencies in the 17 to 19 Hz range — below the threshold of conscious hearing but directly within the resonant frequency range of the human body's organs and, specifically, the fluid within the human eye. At controlled sound pressure levels, these infrasonic pulses create a profound and unmistakable sensation of dread and unease that audiences experience as a physical presence — a feeling that something is wrong before they can intellectually explain why. This is the biological mechanism behind the instinctive fear response to approaching predators or seismic events that human beings evolved over millions of years. Nefron Audio activates it deliberately, on cue, synchronized to the frame.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              For triumph, heroism, and emotional climax sequences, the system generates rapid, concentrated bursts of acoustic energy in the 920 Hz to 4,400 Hz frequency range — the band the human auditory cortex is most sensitive to, corresponding to the resonance of the human vocal tract. When delivered as a sudden surge from near-silence, this frequency profile triggers the release of dopamine and the physical sensation of frisson — the involuntary shivering and goosebumps associated with profound emotional or aesthetic experience. Nefron can engineer this response reliably, reproducibly, and on command.
            </p>
          </section>

          <section id="feature-3" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature Three — Frequency-Optimized Bass Architecture</h4>
            <ImageHolder 
              imageKey="f3"
              title="Feature Three Visualization"
              placeholder="Upload Feature Three Visualization"
              alt="Feature Three Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              One of the most common criticisms of high-powered cinema audio is that excessive bass creates pain — the sensation of pressure in the ears, headaches, and nausea that accompany sustained high-volume low-frequency exposure. This happens because conventional subwoofers transmit their energy primarily through air pressure, which pounds directly against the tympanic membrane.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Nefron's floor-coupled subwoofer architecture bypasses this problem entirely. By transmitting ultra-low-frequency energy (below 40 Hz) structurally through the building — through the floor, into the seating frames, and into the bodies of the audience through bone conduction — the system delivers the physical sensation of massive bass without the painful air-pressure component that causes auditory fatigue. The audience feels the bass in their chest and skeleton at any scale desired, while their ears remain protected. The experience is tactile and visceral in a way that no pneumatic speaker system can replicate, and it can be sustained for an entire three-hour film without causing discomfort.
            </p>
          </section>

          <section id="feature-4" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature Four — Dynamic Real-Time Volume Intelligence</h4>
            <ImageHolder 
              imageKey="f4"
              title="Feature Four Visualization"
              placeholder="Upload Feature Four Visualization"
              alt="Feature Four Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              Every piece of music has a natural emotional arc — quiet passages of tension, building layers of complexity, explosive climaxes, and moments of release. Conventional cinema audio plays a film at a single calibrated volume level, allowing the mix engineer's master recording to dictate all dynamics. This produces a technically correct but emotionally flat experience.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Nefron's AI audio engine analyzes the structure of every piece of music in real time, identifying distinct sections — a solitary vocal, a growing instrumental layer, a full orchestral peak — and dynamically adjusts the decibel output of individual driver groups to match and enhance the emotional arc of the music. A solo vocal passage might hover at a focused, intimate 77 dB from the central drivers. As instrumentation builds, peripheral drivers gradually engage, adding +2 to +3 dB per layer and physically expanding the acoustic footprint of the sound across the room. At the climax, the full array engages at 94 dB, with the ceiling modules angling downward to create a cascading waterfall of sound that envelops every seat simultaneously.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This is not volume automation in the traditional sense. This is the physical expansion and contraction of the acoustic environment itself, synchronized to the emotional heartbeat of the content.
            </p>
          </section>

          <section id="feature-5" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature Five — Autonomous AI Audio-Follows-Video Tracking</h4>
            <ImageHolder 
              imageKey="f5"
              title="Feature Five Visualization"
              placeholder="Upload Feature Five Visualization"
              alt="Feature Five Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              In current cinematic workflows, creating a Dolby Atmos mix requires a team of specialist sound engineers to manually enter spatial coordinates for every audio object in a film — frame by frame, for a two to three hour movie. This process is extraordinarily time-consuming, expensive, and entirely dependent on human judgment and attention to detail. The result is that only films with major studio budgets can afford a truly premium spatial mix.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Nefron Audio's integrated AI engine eliminates this bottleneck entirely.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The system uses convolutional neural network computer vision — the same category of artificial intelligence used in autonomous vehicles and professional video surveillance — to analyze the visual frame of a film in real time. It identifies every significant moving object and character, constructs a three-dimensional depth map of the scene, tracks their trajectories through space across the X, Y, and Z axes simultaneously, and automatically maps the corresponding audio to follow that visual movement. When an actor walks from the left side of the screen to the right, the Nefron system detects this movement, calculates the precise angular trajectory, and commands the corresponding driver modules to physically rotate and follow. No human intervention. No frame-by-frame metadata entry. No specialist engineers required.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This capability has a transformative secondary application: legacy content upmixing. Any film in history — from the earliest stereo recordings to modern 5.1 and 7.1 mixes — can be processed through the Nefron AI engine in real time and converted into a fully spatial, object-tracked audio experience. A black-and-white film from 1950 can be played in a Nefron theater with every voice tracking the actor's face on screen and ambient sound filling the room from all directions. One hundred years of cinema history becomes instantly compatible with the most advanced audio platform ever built.
            </p>
          </section>

          <section id="feature-6" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Feature Six — Unlimited Spatial Object Mapping</h4>
            <ImageHolder 
              imageKey="f6"
              title="Feature Six Visualization"
              placeholder="Upload Feature Six Visualization"
              alt="Feature Six Visualization"
            />
            <p className="text-muted leading-relaxed text-lg">
              Dolby Atmos supports a maximum of 128 simultaneous audio objects. This limit is not arbitrary — it is a direct consequence of the physics of fixed-speaker amplitude panning. Beyond a certain number of objects, the system simply does not have enough independent speaker positions to distinguish between them, and objects begin to crowd and interfere with each other.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Nefron Audio has no such limit.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Because every driver is an independent, physically aimed sound source, the system's object capacity is defined entirely by the number of drivers installed in the theater. In a standard 113-module PLF installation, this means 1,017 simultaneously addressable, independently moving audio objects — eight times the capacity of Dolby Atmos — each one a real physical speaker pointing in a precisely calculated direction in three-dimensional space. A rainstorm can have hundreds of individual raindrops, each physically located in a different part of the room. A crowd scene can have dozens of simultaneous voices, each tracked to the face of the character speaking. A symphony can have every instrument in the orchestra physically present as a distinct, localized sound source surrounding the audience.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              This is not a quantitative improvement on existing technology. It is a qualitative transformation of what cinema audio can be.
            </p>
          </section>

          <section id="architecture" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              SYSTEM ARCHITECTURE — THE INTELLIGENCE BEHIND THE EXPERIENCE
            </h3>
          </section>

          <section id="nefron-cortex" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Nefron Cortex</h4>
            <p className="text-muted leading-relaxed text-lg">
              Controlling over a thousand independently moving drivers in real time requires computational power far beyond a standard audio processor. Each Nefron installation is powered by a dedicated Central Processing Server — the Nefron Cortex — scaled to the size of the installation.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              For a flagship PLF theater, the Cortex is built around Dual AMD EPYC server processors providing up to 128 physical processing cores for audio routing and network management, combined with Dual NVIDIA RTX 6000 Ada graphics processing units providing 36,352 CUDA cores for the simultaneous calculation of 2,034 motor rotation vectors at 60 updates per second. Audio is transmitted across a 10 Gigabit fiber optic backbone using the Dante protocol — the professional standard for high-channel-count networked audio — while motor control commands travel via EtherCAT — the deterministic industrial robotics protocol that guarantees sub-microsecond synchronization across every motor in the system simultaneously.
            </p>
          </section>

          <section id="self-healing" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Self-Healing Intelligence</h4>
            <p className="text-muted leading-relaxed text-lg">
              Every module in the Nefron system is individually addressable and continuously monitored. The Cortex receives real-time telemetry from every driver and every motor in the installation at all times. If a single driver fails, the system detects the fault within milliseconds, recalculates the acoustic geometry of the surrounding modules, and automatically redistributes the failed driver's audio object to its neighbors — physically rotating them to compensate for the coverage gap. The audience hears nothing. The show continues without interruption. Maintenance can be scheduled for the next service window rather than causing an emergency shutdown.
            </p>
          </section>

          <section id="auto-calibration" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Auto-Calibration</h4>
            <p className="text-muted leading-relaxed text-lg">
              When a Nefron system is powered on for the first time in a new theater, it does not require days of manual calibration by specialist engineers. The Cortex automatically queries every module in the network, measures the signal travel time to each one, and uses this data combined with the known physical spacing of the modules to mathematically reconstruct a precise three-dimensional digital twin of the theater. Within minutes of first power-on, the system has mapped the entire acoustic environment and optimized the rotation angles of every driver for the specific geometry of that room.
            </p>
          </section>

          <section id="market-opportunity" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              MARKET OPPORTUNITY — THE SCALE OF THE DISRUPTION
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              The global cinema audio equipment market is currently valued at approximately USD 2.8 billion and is projected to reach USD 4.6 billion by 2030, driven by the aggressive global expansion of Premium Large Format screens and the post-pandemic renaissance of the theatrical moviegoing experience.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Dolby Laboratories, the current dominant force in this market, generated revenues of approximately USD 1.3 billion in 2023, with a substantial portion derived from cinema licensing fees and hardware sales. This revenue comes not from selling superior acoustic physics, but from licensing a format that the entire film industry has standardized on — and that has remained fundamentally unchanged in its core technology since 2012.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The Indian cinema market specifically represents one of the highest-potential deployment environments in the world. India is the largest cinema market by ticket volume globally, with over 1.5 billion tickets sold annually. PVR INOX, India's largest multiplex chain with over 1,700 screens, has been aggressively investing in premium format upgrades. A single chain-wide deployment of Nefron Audio across their top 200 PLF screens would represent a hardware contract of approximately ₹500 to ₹850 Crores, entirely independent of any software licensing revenue.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Beyond traditional cinema, the Nefron platform addresses several adjacent multi-billion dollar markets: premium home theater systems for high-net-worth individuals, professional recording studios requiring the highest-fidelity playback environments, live music venue upgrades, theme park attraction audio, luxury hospitality immersive experience rooms, and military and defense simulation environments where accurate three-dimensional audio is a training requirement.
            </p>
          </section>

          <section id="investment-case" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              THE INVESTMENT CASE
            </h3>
          </section>

          <section id="capex" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Capital Expenditure for Deployment</h4>
            <p className="text-muted leading-relaxed text-lg">
              Nefron Audio installations are priced on a tiered scale corresponding to theater size and module count.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              A small boutique or VIP format screen (approximately 40 modules) carries a total integrated project cost of approximately ₹1.53 Crores, inclusive of hardware, the Cortex server, networking infrastructure, and installation.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              A standard premium multiplex screen (approximately 80 modules) — the highest-volume market segment in India — carries a total cost of approximately ₹3.07 Crores.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              A flagship PLF installation of the 40-meter class (113 modules, 1,017 drivers, 2,034 motors) carries a total project cost of approximately ₹4.25 Crores — positioning Nefron Audio at a 15 to 25 percent cost advantage over comparable Dolby Cinema or IMAX audio installations, while delivering an objectively superior and physically unreplicable acoustic experience.
            </p>
          </section>

          <section id="operating-economics" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Operating Economics</h4>
            <p className="text-muted leading-relaxed text-lg">
              For a 113-module PLF theater running five shows per day, the total electrical consumption under professional-standard continuous-load assumptions is approximately 960 kilowatt-hours per three-hour show, translating to an operational electricity cost of approximately ₹13,000 to ₹15,000 per show at current Indian commercial rates. Across five daily shows, this amounts to an electricity cost of approximately ₹66,000 per day — representing less than 3 percent of gross ticket revenue for a 600-seat theater at average PLF pricing. This cost is entirely manageable within standard cinema operational margins and is competitive with the electricity costs of legacy high-power systems.
            </p>
          </section>

          <section id="revenue-model" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">Revenue Model and Return on Investment</h4>
            <p className="text-muted leading-relaxed text-lg">
              The Nefron Audio business model operates across three parallel revenue streams.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The primary revenue stream is hardware sales — the direct sale of modular speaker systems to cinema chains, venue operators, and premium installation clients. Gross margins on hardware at scale, assuming direct manufacturing relationships with Indian component suppliers, are projected at 35 to 45 percent.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The secondary revenue stream is software licensing — a recurring annual subscription for the Nefron OS AI platform, including the Audio-Follows-Video tracking engine, the legacy content upmixing system, and the dynamic emotional audio processing features. This SaaS component transforms a one-time hardware purchase into a recurring revenue relationship with each installed client and is projected to generate annual per-theater revenues of ₹8 to ₹15 Lakhs.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              The tertiary revenue stream is content royalties — as the Nefron Audio format becomes established, studios and streaming platforms producing content specifically mastered for the Nefron platform will pay a per-title licensing fee, creating a royalty income stream that scales with the growth of the installed base.
            </p>
          </section>

          <section id="seed-investment" className="space-y-4">
            <h4 className="text-xl font-bold text-electric-blue">The Seed Investment Requirement</h4>
            <p className="text-muted leading-relaxed text-lg">
              The current funding requirement is ₹25 to ₹30 Lakhs for the construction and demonstration of a fully functional single-module prototype. This prototype will physically demonstrate rotating driver actuation, real-time AI audio tracking, and the acoustic quality differential between Nefron-steered sound and conventional fixed-speaker panning — giving potential strategic partners and Series A investors a tangible, experiential proof of concept rather than a theoretical presentation.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Upon successful prototype validation, the Series A raise of ₹3 to ₹5 Crores will fund the construction of a 15-module demonstration room, the filing of core mechanical and software patents across the key markets of India, United States, and European Union, and the initiation of conversations with PVR INOX, Cinepolis India, and select international Premium Large Format operators.
            </p>
          </section>

          <section id="why-now" className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground border-l-4 border-electric-blue pl-4">
              WHY THIS. WHY NOW. WHY SANTHOSH.
            </h3>
            <p className="text-muted leading-relaxed text-lg">
              The cinema industry is at an inflection point. Streaming platforms have permanently altered the casual moviegoing habit. The theaters that will survive and thrive are the ones that deliver an experience so powerful, so physical, and so irreplaceable that no home system can simulate it.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              Dolby Atmos gave the industry object-based audio. That was the software revolution. Nefron Audio is the hardware revolution that completes it — the moment when the speakers themselves finally learned to move.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              My name is Santhosh. I am the founder of Nefron Audio. I developed this concept from first principles, driven by a simple conviction: that the future of cinema is not louder — it is more real. That the audience in seat number one and the audience in seat number 500 both paid the same price and both deserve the same extraordinary experience.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              I built Nefron Audio to deliver that promise. And I am looking for partners who believe, as I do, that the most powerful technology in the world is the kind that makes people feel something.
            </p>
            <p className="text-muted leading-relaxed text-lg">
              For investment inquiries, technical documentation, and prototype demonstration requests, please use the contact options available in this application.
            </p>
            <p className="text-muted leading-relaxed text-sm font-bold pt-4">
              © 2026 Nefron Audio. All concepts, architectural designs, and system specifications described herein are the original intellectual property of the founder and are in the process of formal patent registration.
            </p>
          </section>
        </div>

        {/* Footer Info */}
        <div className="pt-12 pb-8 text-[10px] text-muted uppercase tracking-[0.3em] font-bold">
          Nefron Audio AI &copy; 2026 • Version 2.4.0
        </div>
      </div>
    ), [
      images,
      loadingStates,
      uploadingStates,
      isAdmin,
      handleZoom
    ]);

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="h-[calc(100vh-80px)] flex flex-col items-center justify-start p-6 md:p-12 overflow-y-auto custom-scrollbar"
      >
        {mainContent}

        {/* Full Screen Image Overlay */}
        <FullScreenOverlay 
          src={fullScreenImage} 
          onClose={() => handleZoom(null)} 
        />
      </motion.div>
      <AboutAiGuide />
    </>
  );
}
