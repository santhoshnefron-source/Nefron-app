'use client';

import * as React from 'react';
import { SplashScreen } from './splash-screen';
import { cn } from '@/src/lib/utils';
import { NefronLogo } from './icons';
import { MoreHorizontal, Info, Cpu, ChevronLeft, Settings, Sun, Moon, Check, Sparkles, History, LogOut, User as UserIcon, X as CloseIcon, Trash2, Loader2, Mic } from 'lucide-react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, User, db } from '../lib/firebase';
import { collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, Timestamp, deleteDoc, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

import { ErrorBoundary } from './error-boundary';
import { AboutPage } from './about-page';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: any[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, setQuotaError?: (val: boolean) => void) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  const isQuotaError = errorMessage.toLowerCase().includes('quota') || errorMessage.toLowerCase().includes('limit exceeded');
  
  if (isQuotaError && setQuotaError) {
    setQuotaError(true);
    console.warn('Firestore Quota Exceeded. The app will continue in offline/limited mode.');
    return;
  }

  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  if (!isQuotaError) {
    throw new Error(JSON.stringify(errInfo));
  }
}

interface Chat {
  id: string;
  title: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = React.useState(true);
  const [splashFinished, setSplashFinished] = React.useState(false);
  const [user, setUser] = React.useState<User | null>(null);
  const [theme, setTheme] = React.useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      try {
        return (localStorage.getItem('nefron-theme') as 'dark' | 'light') || 'dark';
      } catch (e) {
        return 'dark';
      }
    }
    return 'dark';
  });
  const [colorTheme, setColorTheme] = React.useState<'purple' | 'electric'>(() => {
    if (typeof window !== 'undefined') {
      try {
        return (localStorage.getItem('nefron-color-theme') as 'purple' | 'electric') || 'electric';
      } catch (e) {
        return 'electric';
      }
    }
    return 'electric';
  });
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [menuView, setMenuView] = React.useState<'main' | 'settings'>('main');
  const [activePage, setActivePage] = React.useState<'ai' | 'about'>(() => {
    // Always default to about on fresh load if not specified
    return 'about';
  });
  const [isHistoryOpen, setIsHistoryOpen] = React.useState(false);
  const [authError, setAuthError] = React.useState<string | null>(null);
  const [chats, setChats] = React.useState<Chat[]>([]);
  const [currentChatId, setCurrentChatId] = React.useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = React.useState(false);
  const [quotaError, setQuotaError] = React.useState<boolean>(false);
  const [hasGrantedMic, setHasGrantedMic] = React.useState<boolean | null>(null);
  const [showMicPrompt, setShowMicPrompt] = React.useState(false);
  const [micError, setMicError] = React.useState<string | null>(null);
  const settingsRef = React.useRef<HTMLDivElement>(null);
  const historyRef = React.useRef<HTMLDivElement>(null);
  const longPressTimerRef = React.useRef<NodeJS.Timeout | null>(null);
  const hasInitializedRef = React.useRef(false);

  const generateAnonymousName = () => {
    const adjectives = ['Visionary', 'Echo', 'Sonic', 'Harmonic', 'Strategic', 'Quantum', 'Ethereal', 'Resonant', 'Dynamic', 'Stellar'];
    const nouns = ['Session', 'Dialogue', 'Vision', 'Frequency', 'Pulse', 'Nexus', 'Thread', 'Stream', 'Wave', 'Core'];
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    const num = Math.floor(Math.random() * 900) + 100;
    return `${adj} ${noun} #${num}`;
  };

  // Auth listener
  React.useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        // Check if this is the first time the app is being initialized for this user/browser
        // Using a fresh key to ensure the new defaults are applied to existing users who haven't set preferences
        try {
          const isInitialized = localStorage.getItem('nefron-setup-final');
          
          if (!isInitialized) {
            // First time login - enforce requested defaults
            setTheme('dark');
            setColorTheme('electric');
            localStorage.setItem('nefron-theme', 'dark');
            localStorage.setItem('nefron-color-theme', 'electric');
            localStorage.setItem('nefron-setup-final', 'true');
          }
        } catch (e) {
          console.warn("LocalStorage access failed:", e);
        }
      }
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []); // Empty dependency array for the listener

  // Fetch chats
  React.useEffect(() => {
    if (!user) {
      setChats([]);
      hasInitializedRef.current = false;
      return;
    }

    const q = query(
      collection(db, 'chats'),
      where('userId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chatList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Chat[];
      setChats(chatList);
      setQuotaError(false); // Reset on success
      
      // Only auto-select on the VERY FIRST load of a non-empty chat list
      if (!hasInitializedRef.current && chatList.length > 0) {
        setCurrentChatId(chatList[0].id);
        hasInitializedRef.current = true;
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'chats', setQuotaError);
    });

    return () => unsubscribe();
  }, [user]);

  // Fetch user profile for mic permission
  React.useEffect(() => {
    if (!user) {
      setHasGrantedMic(null);
      setShowMicPrompt(false);
      return;
    }

    const userDocRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userDocRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setHasGrantedMic(data.hasGrantedMicPermission || false);
        setQuotaError(false);
        
        // Only show prompt if they haven't granted it AND haven't explicitly dismissed it
        if (data.hasGrantedMicPermission !== true && !data.micPromptDismissed) {
          setShowMicPrompt(true);
        } else {
          setShowMicPrompt(false);
        }
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`, setQuotaError);
    });

    return () => unsubscribe();
  }, [user]);

  const handleGrantMicPermission = async () => {
    setMicError(null);
    try {
      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('MediaDevicesNotSupported');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(track => track.stop());
      
      if (user) {
        await updateDoc(doc(db, 'users', user.uid), {
          hasGrantedMicPermission: true,
          updatedAt: serverTimestamp()
        });
      }
      setHasGrantedMic(true);
      setShowMicPrompt(false);
    } catch (error: any) {
      console.error("Microphone permission denied during prompt:", error);
      
      const isIframe = typeof window !== 'undefined' && window.self !== window.top;
      
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError' || error.message?.includes('denied')) {
        setMicError(
          isIframe 
            ? "Microphone access was denied. Browsers often block microphone access inside previews. Please click 'Open in New Tab' at the top right of the screen to use voice features."
            : "Microphone access was denied. Please check your browser's address bar or site settings to 'Allow' microphone access."
        );
      } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
        setMicError("No microphone was found on your device. Please connect a microphone and try again.");
      } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
        setMicError("Your microphone is already in use by another application.");
      } else if (error.message === 'MediaDevicesNotSupported') {
        setMicError("Your browser does not support microphone access in this context.");
      } else {
        setMicError(`Microphone error: ${error.message || 'Unknown error'}. Please try again.`);
      }
    }
  };

  const handleSkipMicPermission = async () => {
    if (user) {
      try {
        // We save it as false explicitly so we don't prompt again this session
        // but they can still try to enable it later via settings or mic buttons
        await updateDoc(doc(db, 'users', user.uid), {
          hasGrantedMicPermission: false,
          updatedAt: serverTimestamp(),
          micPromptDismissed: true
        });
      } catch (e) {
        console.error("Error skipping mic permission:", e);
      }
    }
    setShowMicPrompt(false);
  };

  const createNewChat = async () => {
    if (!user) return null;
    // If already in a new/empty chat state, don't create another one
    if (currentChatId === null) return null;
    
    // Just set currentChatId to null to indicate a "new chat" state
    // The actual Firestore document will be created when the first message is sent
    setCurrentChatId(null);
    setIsHistoryOpen(false);
    return null;
  };

  // This is called by ChatInterface when the first message is sent in a null chatId state
  const handleNewChatCreation = async () => {
    if (!user) return null;
    try {
      const docRef = await addDoc(collection(db, 'chats'), {
        userId: user.uid,
        title: 'New Vision Session', // Temporary title, will be updated by ChatInterface
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setCurrentChatId(docRef.id);
      return docRef.id;
    } catch (error) {
      console.error("Error creating chat:", error);
      return null;
    }
  };

  const deleteChat = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'chats', id));
      if (currentChatId === id) {
        setCurrentChatId(null);
      }
    } catch (error) {
      console.error("Error deleting chat:", error);
    }
  };

  const handleLongPressStart = () => {
    longPressTimerRef.current = setTimeout(() => {
      setIsHistoryOpen(true);
    }, 1200);
  };

  const handleLongPressEnd = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handleLogin = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      console.error("Login failed:", error);
      if (error.code === 'auth/popup-closed-by-user') {
        setAuthError("The login popup was closed before completion. Please try again.");
      } else if (error.code === 'auth/unauthorized-domain') {
        const currentDomain = window.location.hostname;
        setAuthError(`This domain (${currentDomain}) is not authorized. Please make sure you added the domain to the NEW studio-8672... project.`);
      } else {
        setAuthError(error.message || "An unexpected error occurred during login.");
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    auth.signOut();
    setCurrentChatId(null);
    try {
      sessionStorage.removeItem('nefron_narrator_greeted');
    } catch (e) {}
  };

  // Initialize theme from localStorage as soon as possible is now handled by lazy state initialization
  React.useLayoutEffect(() => {
    // We still apply the theme to the document element here to ensure it's set before first paint
    if (theme === 'light') {
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
    }
    document.documentElement.setAttribute('data-color-theme', colorTheme);
  }, []);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
        setMenuView('main');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleTheme = (newTheme: 'dark' | 'light') => {
    setTheme(newTheme);
    localStorage.setItem('nefron-theme', newTheme);
  };

  const toggleColorTheme = (newColorTheme: 'purple' | 'electric') => {
    setColorTheme(newColorTheme);
    localStorage.setItem('nefron-color-theme', newColorTheme);
  };

  React.useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.add('light');
      document.body.style.backgroundColor = '#F1F5F9'; // slate-50
    } else {
      document.documentElement.classList.remove('light');
      document.body.style.backgroundColor = '#0B0C10'; // black-deep
    }
    document.documentElement.setAttribute('data-color-theme', colorTheme);
  }, [theme, colorTheme]);

  const handleSplashFinished = React.useCallback(() => {
    setSplashFinished(true);
  }, []);

  if (!splashFinished) {
    return <SplashScreen onFinished={handleSplashFinished} />;
  }

  if (loading) {
    return null; // Auth is still checking, but splash is done (unlikely given 7s duration)
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-black-deep flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-gray-dark border border-foreground/10 rounded-3xl p-8 text-center shadow-2xl">
          <NefronLogo className="w-20 h-20 mx-auto mb-6" />
          <h1 className="text-3xl font-headline tracking-widest neon-glow bg-gradient-to-r from-[var(--logo-gradient-start)] via-[var(--logo-gradient-mid)] to-[var(--logo-gradient-end)] bg-clip-text text-transparent mb-4">
            Nefron Audio
          </h1>
          <p className="text-muted mb-8">Sign in to access your visionary audio AI assistant and keep your conversations synced.</p>
          
          {authError && (
            <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-sm">
              {authError}
            </div>
          )}

          <button
            onClick={handleLogin}
            disabled={isLoggingIn}
            className={cn(
              "w-full py-4 rounded-2xl bg-electric-blue text-white font-bold hover:bg-electric-blue/90 transition-all shadow-lg shadow-electric-blue/20 flex items-center justify-center gap-3",
              isLoggingIn && "opacity-70 cursor-not-allowed"
            )}
          >
            {isLoggingIn ? (
              <>
                <Loader2 className="animate-spin" size={20} />
                Signing in...
              </>
            ) : (
              <>
                <UserIcon size={20} />
                Continue with Google
              </>
            )}
          </button>
          
          <p className="mt-6 text-[10px] text-muted uppercase tracking-widest">
            Ensure popups are enabled for this site
          </p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className={cn('min-h-screen transition-colors duration-300 bg-black-deep dark:bg-black-deep light:bg-slate-50')}
      >
        <div className="flex flex-col min-h-screen">
          <header className="fixed top-0 left-0 right-0 z-50 flex flex-col bg-black-deep/80 backdrop-blur-md border-b border-gray-dark shadow-lg transition-colors duration-300">
            <AnimatePresence>
              {quotaError && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="bg-red-500/20 text-red-400 text-[10px] py-1.5 px-4 text-center font-bold tracking-widest border-b border-red-500/30 overflow-hidden leading-tight"
                >
                  ⚡ FIRESTORE QUOTA EXCEEDED. READS ARE CURRENTLY LIMITED. RESET AT MIDNIGHT. <br className="sm:hidden" />
                  SEE MORE AT FIREBASE.GOOGLE.COM/PRICING
                </motion.div>
              )}
            </AnimatePresence>
            <div className="h-20 flex items-center justify-between px-4 md:px-8">
              <div className="flex items-center gap-2 md:gap-4">
                <NefronLogo className="w-8 h-8 md:w-10 md:h-10" />
                <h2 className={cn(
                  "text-lg sm:text-xl md:text-2xl font-headline tracking-widest neon-glow bg-gradient-to-r from-[var(--logo-gradient-start)] via-[var(--logo-gradient-mid)] to-[var(--logo-gradient-end)] bg-clip-text text-transparent whitespace-nowrap",
                  theme === 'light' ? "font-bold" : "font-light"
                )}>
                  Nefron Audio
                </h2>
              </div>
              <div className="flex items-center gap-1 relative">
              {/* New Chat Button - Only visible on AI page */}
              {activePage === 'ai' && (
                <div className="relative" ref={historyRef}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={createNewChat}
                    onMouseDown={handleLongPressStart}
                    onMouseUp={handleLongPressEnd}
                    onMouseLeave={handleLongPressEnd}
                    onTouchStart={handleLongPressStart}
                    onTouchEnd={handleLongPressEnd}
                    className={cn(
                      "relative flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-300 group overflow-hidden",
                      theme === 'light'
                        ? "bg-white border-electric-blue/20 text-electric-blue shadow-sm hover:shadow-md hover:border-electric-blue/40"
                        : "bg-gradient-to-r from-electric-blue/20 to-electric-green/20 border border-electric-blue/30 text-electric-blue hover:text-electric-green hover:border-electric-green/50"
                    )}
                    title="New Vision (Long press for history)"
                  >
                    {/* Animated background glow */}
                    <div className="absolute inset-0 bg-gradient-to-r from-electric-blue/10 to-electric-green/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    
                    {/* Shimmer effect */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12"
                      initial={{ x: '-100%' }}
                      animate={{ x: '200%' }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                    />
                    
                    <Sparkles size={18} className="relative z-10 group-hover:rotate-12 transition-transform" />
                    <span className="relative z-10 text-xs font-bold tracking-widest uppercase hidden sm:block">New Vision</span>
                    
                    {/* Pulsing ring */}
                    <div className="absolute inset-0 rounded-full border border-electric-blue/50 animate-ping opacity-20 group-hover:opacity-40" />
                  </motion.button>

                  <AnimatePresence>
                    {isHistoryOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 top-full mt-2 w-72 bg-gray-dark border border-foreground/10 rounded-xl shadow-2xl z-50 overflow-hidden"
                    >
                      <div className="p-2">
                        <div className="flex items-center justify-between px-3 py-2 border-b border-foreground/5 mb-2">
                          <div className="flex items-center gap-2 text-muted">
                            <History size={14} />
                            <span className="text-[10px] font-bold uppercase tracking-widest">Recent Chats</span>
                          </div>
                          <button 
                            onClick={() => setIsHistoryOpen(false)}
                            className="text-muted hover:text-foreground"
                          >
                            <CloseIcon size={14} />
                          </button>
                        </div>
                        <div className="max-h-64 overflow-y-auto space-y-1 custom-scrollbar">
                          {chats.length === 0 ? (
                            <p className="text-center py-4 text-xs text-muted italic">No recent chats</p>
                          ) : (
                            chats.map(chat => (
                              <ChatHistoryItem 
                                key={chat.id} 
                                chat={chat} 
                                isActive={currentChatId === chat.id}
                                onSelect={(id) => {
                                  setCurrentChatId(id);
                                  setIsHistoryOpen(false);
                                }}
                                onDelete={deleteChat}
                              />
                            ))
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Navigation Menu Button */}
              <div className="relative" ref={settingsRef}>
                <button 
                  onClick={() => {
                    setIsMenuOpen(!isMenuOpen);
                    setMenuView('main');
                  }}
                  className={cn(
                    "p-2 rounded-full transition-all duration-300",
                    isMenuOpen ? "bg-gray-dark text-electric-blue" : "text-electric-blue hover:text-electric-green hover:bg-gray-dark"
                  )}
                >
                  <MoreHorizontal size={24} />
                </button>

                <AnimatePresence>
                  {isMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 top-full mt-2 w-64 bg-gray-dark border border-foreground/10 rounded-xl shadow-2xl z-50 overflow-hidden"
                    >
                      <div className="p-2">
                        {menuView === 'main' ? (
                          <div className="space-y-1">
                            <div className="flex items-center gap-3 px-3 py-3 border-b border-foreground/5 mb-2">
                              <img src={user.photoURL || ''} className="w-8 h-8 rounded-full border border-electric-blue/30" alt="" />
                              <div className="flex flex-col min-w-0">
                                <span className="text-sm font-bold truncate">{user.displayName}</span>
                                <span className="text-[10px] text-muted truncate">{user.email}</span>
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                setActivePage('about');
                                setIsMenuOpen(false);
                              }}
                              className={cn(
                                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                                activePage === 'about' ? "bg-electric-blue/10 text-electric-blue font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                              )}
                            >
                              <Info size={18} />
                              <span>About</span>
                            </button>

                            <button
                              onClick={() => {
                                setActivePage('ai');
                                setIsMenuOpen(false);
                              }}
                              className={cn(
                                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors",
                                activePage === 'ai' ? "bg-electric-blue/10 text-electric-blue font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                              )}
                            >
                              <Cpu size={18} />
                              <span>AI Assistant</span>
                            </button>

                            <button
                              onClick={() => setMenuView('settings')}
                              className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm text-muted hover:bg-black-deep/50 hover:text-foreground transition-colors"
                            >
                              <div className="flex items-center gap-3">
                                <Settings size={18} />
                                <span>Settings</span>
                              </div>
                              <Check size={14} className="opacity-0" /> {/* Spacer */}
                            </button>

                            <div className="border-t border-foreground/5 mt-1 pt-2">
                              <button
                                onClick={handleLogout}
                                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-500 hover:bg-red-500/10 transition-colors"
                              >
                                <LogOut size={18} />
                                <span>Sign Out</span>
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            <button 
                              onClick={() => setMenuView('main')}
                              className="flex items-center gap-2 px-3 py-1 text-xs text-electric-blue hover:text-electric-green transition-colors mb-2"
                            >
                              <ChevronLeft size={14} />
                              <span>Back to Menu</span>
                            </button>

                            <div>
                              <p className="px-3 py-1 text-[10px] font-bold text-muted uppercase tracking-widest">Display Mode</p>
                              <div className="space-y-1 mt-1">
                                <button
                                  onClick={() => toggleTheme('light')}
                                  className={cn(
                                    "w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors",
                                    theme === 'light' ? "bg-electric-blue/10 text-foreground font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                                  )}
                                >
                                  <div className="flex items-center gap-3">
                                    <Sun size={16} />
                                    <span>Light Mode</span>
                                  </div>
                                  {theme === 'light' && <Check size={14} className="text-electric-blue" />}
                                </button>
                                <button
                                  onClick={() => toggleTheme('dark')}
                                  className={cn(
                                    "w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors",
                                    theme === 'dark' ? "bg-electric-blue/10 text-foreground font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                                  )}
                                >
                                  <div className="flex items-center gap-3">
                                    <Moon size={16} />
                                    <span>Dark Mode</span>
                                  </div>
                                  {theme === 'dark' && <Check size={14} className="text-electric-blue" />}
                                </button>
                              </div>
                            </div>

                            <div className="border-t border-foreground/10 pt-2">
                              <p className="px-3 py-1 text-[10px] font-bold text-muted uppercase tracking-widest">Color Theme</p>
                              <div className="space-y-1 mt-1">
                                <button
                                  onClick={() => toggleColorTheme('purple')}
                                  className={cn(
                                    "w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors",
                                    colorTheme === 'purple' ? "bg-electric-blue/10 text-foreground font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                                  )}
                                >
                                  <div className="flex items-center gap-3">
                                    <div className="w-3 h-3 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6]" />
                                    <span>Purple Gradient</span>
                                  </div>
                                  {colorTheme === 'purple' && <Check size={14} className="text-electric-blue" />}
                                </button>
                                <button
                                  onClick={() => toggleColorTheme('electric')}
                                  className={cn(
                                    "w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors",
                                    colorTheme === 'electric' ? "bg-electric-blue/10 text-foreground font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
                                  )}
                                >
                                  <div className="flex items-center gap-3">
                                    <div className="w-3 h-3 rounded-full bg-gradient-to-r from-[#39FF14] to-[#007FFF]" />
                                    <span>Electric Theme</span>
                                  </div>
                                  {colorTheme === 'electric' && <Check size={14} className="text-electric-blue" />}
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </header>
          <main className="flex-1 bg-black-deep overflow-hidden relative pt-20">
            <AnimatePresence mode="wait">
              {activePage === 'ai' ? (
                <motion.div
                  key="ai-page"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="h-full"
                >
                  {React.isValidElement(children) ? React.cloneElement(children as React.ReactElement<any>, { 
                    chatId: currentChatId, 
                    userId: user.uid,
                    onNewChat: handleNewChatCreation
                  }) : children}
                </motion.div>
              ) : (
                <AboutPage />
              )}
            </AnimatePresence>
          </main>
        </div>

        {/* Mic Permission Prompt Overlay */}
        <AnimatePresence>
          {showMicPrompt && user && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center bg-black-deep/80 backdrop-blur-sm p-4"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="max-w-md w-full bg-gray-dark border border-electric-blue/30 rounded-3xl p-8 text-center shadow-[0_0_50px_rgba(0,127,255,0.2)]"
              >
                <div className="w-20 h-20 bg-electric-blue/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-electric-blue/20">
                  <Mic size={40} className="text-electric-blue animate-pulse" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-4">Enable Voice Features</h3>
                <p className="text-muted mb-8 text-sm leading-relaxed">
                  To experience Nefron AI's full voice capabilities, we need your permission to access the microphone. This will only be asked once per account.
                </p>
                
                {micError && (
                  <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-500 text-xs flex flex-col gap-3">
                    <p className="leading-relaxed">{micError}</p>
                    {typeof window !== 'undefined' && window.self !== window.top && (
                      <button 
                        onClick={() => window.open(window.location.href, '_blank')}
                        className="text-[10px] font-bold uppercase tracking-widest underline decoration-red-500/30 hover:decoration-red-500 transition-all text-left"
                      >
                        Open in New Tab ↗
                      </button>
                    )}
                  </div>
                )}

                <div className="flex flex-col gap-3">
                  <button
                    onClick={handleGrantMicPermission}
                    className="w-full py-4 rounded-2xl bg-electric-blue text-white font-bold hover:bg-electric-blue/90 transition-all shadow-lg shadow-electric-blue/20"
                  >
                    Grant Access
                  </button>
                  <button
                    onClick={handleSkipMicPermission}
                    className="w-full py-3 rounded-2xl bg-transparent text-muted hover:text-foreground transition-all text-xs uppercase tracking-widest"
                  >
                    Continue Without Voice
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </ErrorBoundary>
  );
}

interface ChatHistoryItemProps {
  chat: Chat;
  isActive: boolean;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

function ChatHistoryItem({ chat, isActive, onSelect, onDelete }: ChatHistoryItemProps) {
  const x = useMotionValue(0);
  const opacity = useTransform(x, [0, 150], [0, 1]);
  const scale = useTransform(x, [0, 150], [0.5, 1]);
  const [isDeleting, setIsDeleting] = React.useState(false);

  const handleDragEnd = (_: any, info: any) => {
    if (info.offset.x > 150) {
      setIsDeleting(true);
      setTimeout(() => onDelete(chat.id), 300);
    }
  };

  return (
    <div className="relative overflow-hidden rounded-lg">
      <motion.div 
        style={{ opacity, scale }}
        className="absolute inset-0 bg-red-500 flex items-center pl-4 text-white z-0"
      >
        <Trash2 size={16} />
      </motion.div>
      
      <motion.button
        drag="x"
        dragConstraints={{ left: 0, right: 200 }}
        dragElastic={0.1}
        onDragEnd={handleDragEnd}
        style={{ x }}
        onClick={() => onSelect(chat.id)}
        animate={isDeleting ? { x: 400, opacity: 0 } : { x: 0 }}
        className={cn(
          "relative z-10 w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex flex-col gap-0.5 bg-gray-dark",
          isActive ? "bg-electric-blue/10 text-electric-blue font-bold" : "text-muted hover:bg-black-deep/50 hover:text-foreground"
        )}
      >
        <span className="truncate">{chat.title}</span>
        <span className="text-[9px] opacity-50">
          {chat.updatedAt?.toDate ? chat.updatedAt.toDate().toLocaleDateString() : 'Just now'}
        </span>
      </motion.button>
    </div>
  );
}
