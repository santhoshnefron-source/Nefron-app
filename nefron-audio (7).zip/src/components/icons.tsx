import type { SVGProps } from 'react';
import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';

const svgVariants: any = {
  hidden: { opacity: 0, scale: 0 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.5,
      ease: 'easeInOut',
      when: 'beforeChildren',
      staggerChildren: 0.5,
    },
  },
};

const pathVariants: any = {
  hidden: {
    pathLength: 0,
  },
  visible: {
    pathLength: 1,
    transition: {
      duration: 2,
      ease: 'easeInOut',
    },
  },
};

export function NefronLogo(props: SVGProps<SVGSVGElement> & { isThinking?: boolean }) {
  const { isThinking, className, ...svgProps } = props;
  const MotionSvg = motion.svg as any;
  const MotionPath = motion.path as any;
  
  return (
    <MotionSvg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="url(#nefron-splash-gradient)"
      strokeWidth="1"
      strokeLinecap="round"
      strokeLinejoin="round"
      variants={svgVariants}
      initial="hidden"
      animate={isThinking ? {
        scale: [1, 1.05, 1],
        rotate: [0, 2, -2, 0],
        transition: {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }
      } : "visible"}
      className={cn("neon-glow", className)}
      {...svgProps}
    >
      <defs>
        <linearGradient
          id="nefron-splash-gradient"
          x1="0%"
          y1="0%"
          x2="100%"
          y2="100%"
        >
          <stop offset="0%" stopColor="var(--logo-gradient-start)" />
          <stop offset="50%" stopColor="var(--logo-gradient-mid)" />
          <stop offset="100%" stopColor="var(--logo-gradient-end)" />
        </linearGradient>
      </defs>
      <MotionPath variants={pathVariants} d="M8.34,3.49l7.32,17.02" />
      <MotionPath variants={pathVariants} d="M8.34,3.49C2.4,10.15,2.4,13.85,8.34,20.51" />
      <MotionPath variants={pathVariants} d="M15.66,3.49c5.94,6.66,5.94,10.36,0,17.02" />
    </MotionSvg>
  );
}
