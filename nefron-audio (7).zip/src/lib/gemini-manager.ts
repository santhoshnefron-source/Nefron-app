import { GoogleGenAI } from "@google/genai";

class GeminiManager {
  private keys: string[] = [];
  private currentIndex: number = 0;
  private exhaustedKeys: Set<string> = new Set();
  private lastQuotaReset: number = Date.now();

  constructor() {
    this.keyInit();
  }

  private keyInit() {
    const hardcodedKeys = "AIzaSyBLCEEvVP4o3DcTnJP7uHuyeA4uQdrtqAU,AizaSyAl65aicnL6P84O_2Jvq7MUi2kVIRDFndo,AizaSyDEYx-mir9XA9efU5t7v6Gt3fvXPmqWmao,AizaSyDSHWOjOa4Xp6qXwXNgDBPnL-s7QVeIZL8,AizaSyBAcgDiGQGYBHT-hz0NrE4PLlFWGZrIX3Y,AizaSyBJ_Mgv2TZGlVWHWzidmIZJG94_9RujcII,AizaSyCNrohly1s86hVdwjkw33WGNTVUtDYiO3c,AizaSyCyUTjpxfpo_2jhq3C-ZTPwaphDh_lIdXw,AizaSyC-KRok-KJwqLMIGZX1KHOKAnkAxkJK7bw,AizaSyBYJ-ZN3nCNR6Dme8FflqSC1HFwn2qNo2A,AizaSyAVZAl6OGLWImWW0XVRV5kvIBKDeoooSqw,AizaSyDWUggj0k2ck2Jw_3vafUgKM7xOvJPWQsI,AizaSyDkh1cz2oLDTBHXU2cj-5xEtUr1PY4kCs4,AizaSyC9J8XbjPTkYGocRjDMBQdA3zM4st0Kbj0,AizaSyA6Y2BE97FUhIgCWsrko5lY6KBA0462gVQ,AizaSyCLROZoRI_oET_90LoY4Ea0q_thX1i771g,AizaSyBm29A_o9WlKr5S-K0ZlZauZ_GtSQpZOq0,AizaSyBBnm_J-OV4qbz4156axCWb3Kg203sA6b4,AizaSyDk5PFY1qcfOIxH4JwAo5FVMqqS4RaTdoE,AizaSyAT7jd1OAZQutKmtQA_CBBKx6Na-ulUp9U,AizaSyCDN840ZjcZsFDg1-u8U6TkLzScn53wh2c,AizaSyDKGzzmO4b4zRPYq70R2Cjn5sAHaQArWxo,AizaSyB9K2mitWQOb9S3COGZ_yxgAhi5L2knKKo,AizaSyBTsfN_kecZaJp1FhV8j16N1A4sTC2Et2A,AizaSyDN0YTLeaDHlXniJjgCaiYPNbLvVz68ux0,AizaSyDElef-QftY5OHIXN6zhV0Qanc_YPagY4c,AizaSyAH_bEWe46-PbYIUEj-79VNXPFBqHA0yy0,AizaSyAcE-vY-r1sYj_tBi5lfhMcJRoNTdS8gwU,AizaSyDMXzySuigRKnC-oPsyPfS7SM4kcuJEuAQ,AizaSyDfntHkSQTEgPjLUfyWT6pPHgqb9g8oOdo,AizaSyDmce18uCacAOikmCqHmatNAqS30Z7TSmQ,AizaSyDl_07fjKs_xI9_0mGPexZqS6GrHZsNr8M,AizaSyAvbXL7KID_o5YcN5TbFW0wfrrghEF__fQ,AizaSyDLhuf8fdFnrWHWfiu6J8ehl2xI8jx_KSI,AizaSyAWD27VATJ6MBCiTA6LHf_wSu-0urqbbI8,AizaSyD-a7Q_FF1_0-OXuhL7LI0zf5QbGDLUXD0,AizaSyAlTSNlfJISnR6hkUlndoLMbbP0Y3HKP78,AizaSyB9066wy8yKi8YsirT3Llzn05cER4TwWrM,AizaSyBh5B5tPwzBCgFGllH9xZmohmFpdiLTs5k,AizaSyA7wN0O3xSwTpLfxKAfRw7oulKrkfRTZHE,AizaSyAsmXWX6GHg48139r1hJ-m5uNC44al3d_w,AizaSyDU9NVryg1aK4voVaAIJn_p9PJntMqckGM,AizaSyAYfOf9RYS62FDLsRrqC-oRWXDtR_IiM5U,AizaSyBBPj2XyPMGPeiz4XEM4uukLoL7gTxBZYE,AizaSyBZdfPQ5nRnRMswb_ewHj2-kcwoPmHIKgM,AizaSyCQmIiVUyle2bRUyTNandcbreChvICwMdA,AizaSyCUCupY11JWm4P0ieeeDbxrfSwGbEc6xHQ,AizaSyBeKLiAcMI09lBz5OjtiFPTj_mpWfrG88A,AizaSyDFobzyAt7ljL2VwLZpSdaX4aBTUaqxNIA,AizaSyC7qG4Bpa9y-qsLZdgIsi37DRMITeFE1PY,AizaSyCJ0fIhZ6Xit6-QvmGRcyfxSgr1TaoyS2g,AizaSyBWuPK6dE8Abui9oVMtywVsPUor5JT-3fE,AizaSyCbN-wjX7NkHIDGlpzvA5X1uLtiUtUTCsQ,AizaSyAneP4TEZdcZQAFjnJpMihDz9V7eDMUigY,AizaSyBbhvZKfr122RsbmVQ8K5Rm2_mxq-7JCQE,AizaSyC9EKi2Q5PpGqV4RALDfvTG62ESwGkRsnI,AizaSyAuqbQm8ddQiMzYJhvk1raleIXpgKWuMhE,AizaSyALrYyeSgEwAkwLUvgg1ter2v7aAl3xgmI,AizaSyB_O5Gt39_k7H9boiH_uKck5KleNYJKEco,AizaSyAu5596B5EEeoXj5qLqScSqFRzrZrHkK94,AizaSyBWkOZviEEV_lQY01CvctpA1jGcDgIwVag,AizaSyBc-RMlfS9rfvtXaX6Vji4-z8MwvspGzm0,AizaSyA882OAvZSjcBeN4R01i8q4PWQKWij5mNI,AizaSyAFcue5WHv0TN0l4yyMUWKQkjijUKYXDlQ,AizaSyD0sbm4FSXJrIhw6zH9G2Zx-du_9m91LUQ,AizaSyD3QKc6LOf2wfNMMSwMmltfmFnwcmAXmPY,AizaSyBx2KzV-0IOjkbkswgze8W-D13EEubaMIY,AizaSyDRzHoACtkYImBiQb0InO_646ZpVhp1Z_0,AizaSyDshVNHeOwFqTSda2ChJ2ZEemm2yRqinT8,AizaSyAPomZYm1NBBlsM7DZT1LbJzdPYMKX91DU,AizaSyCGfJFdr1Y1t3oeNUtutjXDqywLqOcN12I,AizaSyDUe9CAZpuGtkpLuFiHaAsgUDK8Jvl23Ik,AizaSyAbXQ4jZQBLen9rkN5xFAj9H_5rbSUjQxQ,AizaSyDT_C2ptqKc4VmJtrnz4rm3WgHXAVv0wYw,AizaSyBV7Jgaeu1DX-DbzDRdRP6jMg-H8TkzyOU,AizaSyAWnXg19Y_KG2wOQ1gogYvw6OwXaOlK7jM,AizaSyArbGqK2kyC9jSPLYUODJMbinkhFswJGjg,AizaSyAiHAqVP30gMWM-Uwc2yEinGr5UjesQM9E,AizaSyCrRzIvlgjaJrRlWp3pczOWg77IiFxuRFg,AizaSyC7qBGgQubghPsciNnJLzZz4jz-ba-za64,AizaSyBigrTWtcL4lWLMwaCbTH58yUuFNajgS7U,AizaSyBj_sC9JHvtOwh7jjPFxULpI_etC6jy8Ss,AizaSyDgPKundrOnN644ro1XCsaPYop1b6-CP80,AizaSyAfR-brrpAs_E0AwHuNha3YYKDrbQGJaEY,AizaSyDc-7Vi0Wa0Daz6K8FJiXVTE8eFHLBMfIw,AizaSyB2u8YeqReMK92DXzRVsBkflan1zYAaK3E,AizaSyAwIhvN86XWlK4uSFOH4E675DpmyBlFCjA,AizaSyC-b388B-e7dJwklP3PpCti9FziyHnxaIk,AizaSyAi6xXjMImZrU0VjnwniiYeAKp7Mh5p18o,AizaSyD_WWu_pqqMsSoNzb-xGRFgJ1KQKDmqqAw,AizaSyALYkVfmlnu2jyasL70FtI1hh49RiIU2sI,AizaSyAlZzecrpLZ67f8S1GeiCZTUrA7R8Sx87U,AizaSyBdstg0Db1yLsi9F0trtCtptTmtfLsyQiA,AizaSyA5EJ2zbfvxeVgtXzx4rHyT522Qu8OlWNg,AizaSyCPt_DJVmg8ewjZFKp1Mx04Q7kJ005-0Qc,AizaSyDYUhbVuWVww6O5_DnyQuFKSRXGJB9iYTU,AizaSyAtKEaPCaH0JPkU8QCsib_tGngIYZHZReg,AizaSyD11jwFbcIYc-qagLZV5VIhGB9sz10ZO7k,AizaSyAj1RvG18FTtt9_mUA2izWOaQxXLjY4tBY,AizaSyD7eF-qZg0VH4CJzusR_fziDpNEiAxVNpk,AizaSyBPy03isP166YJT5mVkGCOjpFCeqxWNA0I,AizaSyD8VTvMvWnRCv17UDZlXEwctIKejTl9BWA";
    const rawKeys = hardcodedKeys || (import.meta as any).env.VITE_GEMINI_API_KEY || '';
    // Support common separators: comma, semicolon, space, or newline
    this.keys = rawKeys.split(/[,;\s\n]+/).map((k: string) => k.trim()).filter(Boolean);
    
    if (this.keys.length > 0) {
        console.log(`GeminiManager: Successfully loaded ${this.keys.length} API keys for rotation.`);
    } else {
        console.warn('GeminiManager: No API keys found in VITE_GEMINI_API_KEY.');
    }
    
    // Recovery: If it's been more than 1 hour, clear exhausted keys (optimistic reset)
    if (Date.now() - this.lastQuotaReset > 3600000) {
        this.exhaustedKeys.clear();
        this.lastQuotaReset = Date.now();
    }
  }

  getApiKey(): string | null {
    // Re-check keys in case env changed without restart (unlikely but safe)
    if (this.keys.length === 0) {
        this.keyInit();
    }
    
    if (this.keys.length === 0) return null;
    
    // Find first key that isn't exhausted
    for (let i = 0; i < this.keys.length; i++) {
        const index = (this.currentIndex + i) % this.keys.length;
        if (!this.exhaustedKeys.has(this.keys[index])) {
            return this.keys[index];
        }
    }
    
    // If all are exhausted, return null or the first one if you want to keep retrying
    return null; 
  }

  markExhausted(key: string, isPermanent: boolean = true) {
    if (!key) return;
    
    if (isPermanent) {
      this.exhaustedKeys.add(key);
      console.warn(`Gemini API Key exhausted (Permanent): ${this.getMaskedKey(key)}. Switching to next.`);
    } else {
      // For transient errors, we rotate but don't add to exhaustedKeys immediately
      console.warn(`Gemini API Key glitch (Transient): ${this.getMaskedKey(key)}. Rotating cluster...`);
    }

    // Rotate index to next key
    const index = this.keys.indexOf(key);
    if (index !== -1) {
        this.currentIndex = (index + 1) % this.keys.length;
    }
  }

  hasMultipleKeys(): boolean {
    return this.keys.length > 1;
  }

  getAvailableKeysCount(): number {
    return this.keys.filter(k => !this.exhaustedKeys.has(k)).length;
  }

  getTotalKeysCount(): number {
    return this.keys.length;
  }

  private getMaskedKey(key: string): string {
    if (key.length <= 8) return "****";
    return key.substring(0, 4) + "****" + key.substring(key.length - 4);
  }

  isQuotaError(error: any): boolean {
    if (!error) return false;
    
    // Extract error text from various possible formats
    const msg = (error?.message || error?.toString() || String(error)).toLowerCase();
    const fullErrorStr = (typeof error === 'object') ? JSON.stringify(error).toLowerCase() : '';
    
    const isMatched = (str: string) => msg.includes(str) || fullErrorStr.includes(str);
    
    // Check for Quota/Rate Limit (429)
    if (isMatched('quota') || isMatched('rate limit') || isMatched('429')) {
        return true;
    }
    
    // Check for Internal/Network/Transient issues (500, 503, etc)
    if (isMatched('internal error') || 
        isMatched('500') || 
        isMatched('503') ||
        isMatched('network error') || 
        isMatched('failed to fetch') ||
        isMatched('aborted') ||
        isMatched('service unavailable') ||
        isMatched('deadline exceeded')) {
        return true;
    }
    
    return false;
  }

  // Helper to check if an error is specifically a Quota issue vs a transient one
  isSpecificallyQuota(error: any): boolean {
    const msg = (error?.message || error?.toString() || String(error)).toLowerCase();
    return msg.includes('quota') || msg.includes('rate limit') || msg.includes('429');
  }
}

export const geminiManager = new GeminiManager();
