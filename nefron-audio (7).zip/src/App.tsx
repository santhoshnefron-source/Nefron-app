/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DashboardLayout } from './components/dashboard-layout';
import { ChatInterface } from './components/chat-interface';

export default function App() {
  return (
    <DashboardLayout>
      <ChatInterface />
    </DashboardLayout>
  );
}
